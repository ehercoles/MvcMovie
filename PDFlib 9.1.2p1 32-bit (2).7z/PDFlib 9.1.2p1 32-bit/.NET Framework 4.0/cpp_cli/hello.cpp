//
// PDFlib client: hello example in C++/CLI calling into the PDFlib .NET assembly
//

#using "pdflib_dotnet.dll"

using namespace System;
using namespace PDFlib_dotnet;

int
main(void)
{
    try
    {
	PDFlib p;

	//  This means we must check return values of load_font() etc.
	p.set_parameter("errorpolicy", "return");

	if (p.begin_document("hello.pdf", "") == -1)
	{
	    Console::WriteLine("Error: " + p.get_errmsg());
	    return 2;
	}

	p.set_info("Creator", "hello.cpp");
	p.set_info("Author", "Thomas Merz");
	p.set_info("Title", "Hello, world (C++/CLI .NET)!");

	p.begin_page_ext(595.0, 842.0, "");

	const int font = p.load_font("Helvetica-Bold", "unicode", "");
	if (font == -1)
	{
	    Console::WriteLine("Error: " + p.get_errmsg());
	    return(2);
	}
	p.setfont(font, 24);
	p.set_text_pos(50, 700);
	p.show("Hello, world!");
	p.continue_text("(says C++/CLI .NET)");
	p.end_page_ext("");

	p.end_document("");
    }
    catch (PDFlibException^ ex)
    {
	Console::WriteLine("PDFlib exception occurred in hello sample: ");
	Console::WriteLine("[" + ex->get_errnum() + "] " + ex->get_apiname()
	    + ": " + ex->get_errmsg());
	return 2;
    }

    return 0;
}
