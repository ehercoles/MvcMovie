' $Id$
'
' Block starter:
' Import a PDF page containing blocks and fill text and image
' blocks with some data. For each addressee of the simulated
' mailing a separate page with personalized information is
' generated.
' A real-world application would of course fill the blocks with data
' retrieved from some external data source.
'
' Required software: PPS 9
' Required data: input PDF, image
'

Imports System
Imports System.Text
Imports PDFlib_dotnet

Module starter_block
  Sub Main()

        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = "../../data"
        Dim outfile As String = "starter_block.pdf"
        Dim infile As String = "block_template.pdf"
        Dim imagefile As String = "new.jpg"

        Dim p As PDFlib

        Dim i, j, no_of_input_pages, pageno, indoc, image As Integer
        Dim objtype As String

        Dim optlist As New StringBuilder()
        Dim buf As New StringBuilder()
        

        ' Names of the person-related blocks contained on the imported page
        Dim addressblocks() As String = {"name", "street", "city"}

        ' number of address blocks

        Dim nblocks As Integer = addressblocks.Length


        ' Personalization data for the recipients
        Dim recipients(,) As String = { _
            {"Mr Maurizio Moroni", "Strada Provinciale 124", "Reggio Emilia"}, _
            {"Ms Dominique Perrier", "25, rue Lauriston", "Paris"}, _
            {"Mr Liu Wong", "55 Grizzly Peak Rd.", "Butte"} _
        }

        Dim nrecipients As Integer = recipients.Length / 3

        ' Static text simulates database-driven variable contents
        Dim blockdata(,) As String = {
            {"intro", "Dear Paper Planes Fan,"}, _
            {"announcement",
                "Our <fillcolor=red>BEST PRICE OFFER<fillcolor=black> includes today:" & _
                    "\n\n" & _
                "Long Distance Glider\nWith this paper rocket you can send all your " & _
                "messages even when sitting in a hall or in the cinema pretty near " & _
                "the back.\n\n" & _
                "Giant Wing\nAn unbelievable sailplane! It is amazingly robust and " & _
                "can even do aerobatics. But it is best suited to gliding.\n\n" & _
                "Cone Head Rocket\nThis paper arrow can be thrown with big swing. " & _
                "We launched it from the roof of a hotel. It stayed in the air a " & _
                "long time and covered a considerable distance.\n\n" & _
                "Super Dart\nThe super dart can fly giant loops with a radius of 4 " & _
                "or 5 meters and cover very long distances. Its heavy cone point is " & _
                "slightly bowed upwards to get the lift required for loops.\n\n" & _
                "Visit us on our Web site at www.kraxi.com!"}, _
            {"goodbye", "Yours sincerely,\nVictor Kraxi"} _
        }

        ' create a new PDFlib object
        p = New PDFlib()

        Try

            ' This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return")

            ' Set the search path for fonts and PDF files 
            p.set_option("SearchPath={{" + searchpath + "}}")

            If (p.begin_document(outfile, _
                "destination={type=fitwindow} pagelayout=singlepage") = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                Return
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_block")

            ' Open the Block template which contains PDFlib Blocks
            indoc = p.open_pdi_document(infile, "")
            If (indoc = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                Return
            End If

            no_of_input_pages = p.pcos_get_number(indoc, "length:pages")

            ' Prepare all pages of the input document. We assume a small
            ' number of input pages and a large number of generated output
            ' pages. Therefore it makes sense to keep the input pages
            ' open instead of opening the pages again for each recipient.
            Dim pagehandles(no_of_input_pages) As Integer

            For pageno = 1 To no_of_input_pages Step 1
                pagehandles(pageno) = p.open_pdi_page(indoc, 1, "cloneboxes")
                If (pagehandles(pageno) = -1) Then
                    Console.WriteLine("Error: {0}", p.get_errmsg())
                    Return
                End If
            Next


            image = p.load_image("auto", imagefile, "")

            If (image = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                Return
            End If

            ' Duplicate input pages for each recipient and fill Blocks

            ' Based on the imported page generate several pages with the blocks
            ' being filled with data related to different persons
            '/
            For i = 0 To nrecipients - 1 Step 1
                'Loop over all pages of the input document
                For pageno = 1 To no_of_input_pages Step 1

                    ' Start the output page with a dummy size
                    p.begin_page_ext(10, 10, "")

                    ' Place the imported page on the output page, and clone all
                    ' page boxes which are present in the input page; this will
                    ' override the dummy size used in begin_page_ext().
                    '/
                    p.fit_pdi_page(pagehandles(pageno), 0, 0, "cloneboxes")

                    ' Option list for text blocks
                    optlist.Length = 0
                    optlist.Append("encoding=winansi embedding escapesequence")

                    ' Loop over all recipient-specific Blocks. Fill each
                    ' Block with the corresponding person's address data.
                    '/
                    For j = 0 To addressblocks.Length - 1 Step 1
                        ' Check whether the Block is present on the imported page
                        ' type "dictionary" means that the Block is present.

                        objtype = p.pcos_get_string(indoc, _
                                                    "type:pages[" & pageno - 1 & "]/blocks/" & addressblocks(j))
                        If objtype = "dict" Then
                            If (p.fill_textblock(pagehandles(pageno), addressblocks(j), _
                                    recipients(i, j), optlist.ToString()) = -1) Then
                                Console.WriteLine("Warning: {0}", p.get_errmsg())
                            End If
                        End If
                    Next

                    For j = 0 To nblocks - 1 Step 1
                        ' Check whether the Block is present on the page 
                        objtype = p.pcos_get_string(indoc, _
                                                    "type:pages[" & pageno - 1 & "]/blocks/" & blockdata(j, 0))
                        If objtype = "dict" Then
                            If (p.fill_textblock(pagehandles(pageno), blockdata(j, 0), _
                                    blockdata(j, 1), optlist.ToString()) = -1) Then
                                Console.WriteLine("Warning: {0}", p.get_errmsg())
                            End If
                        End If
                    Next

                    ' Fill the image block
                    optlist.Length = 0
                    optlist.Append("")        ' Option list
                    If (p.fill_imageblock(pagehandles(pageno), "icon", image, optlist.ToString()) _
                            = -1) Then
                        Console.WriteLine("Warning: {0}", p.get_errmsg())
                    End If

                    p.end_page_ext("")
                Next

            Next
            ' Close all input pages
            For pageno = 1 To no_of_input_pages Step 1
                p.close_pdi_page(pagehandles(pageno))
            Next

            p.close_pdi_document(indoc)
            p.close_image(image)

            p.end_document("")

        Catch e As PDFlibException
            Console.Error.WriteLine("PDFlib exception occurred:")
            Console.Error.WriteLine("[{0}] {1}: {2}", e.get_errnum(), e.get_apiname(), e.get_errmsg)
        Catch e As System.Exception
            Console.Error.WriteLine(e.ToString())
        Finally
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try
  End Sub
End Module
