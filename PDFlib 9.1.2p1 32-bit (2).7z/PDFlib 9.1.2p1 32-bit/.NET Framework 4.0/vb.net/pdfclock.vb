' $Id: pdfclock.vb
'
' PDFlib client: pdfclock example in vb.NET
'

Imports System
Imports System.Text
Imports PDFlib_dotnet

Class pdfclock
    Public Shared Sub Main()
        Dim p As PDFlib_dotnet.PDFlib
        Dim ltime As System.DateTime
        Dim RADIUS As Double
        Dim MARGIN As Double
        Dim alpha As Double

        RADIUS = 200.0
        MARGIN = 20.0

        p = New PDFlib()

        Try
	    ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

            If (p.begin_document("pdfclock.pdf", "") = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                End
            End If

            p.set_info("Creator", "pdfclock.vb")
            p.set_info("Author", "Rainer Schaaf")
            p.set_info("Title", "PDF clock (VB.NET)")

            p.begin_page_ext((2 * (RADIUS + MARGIN)), (2 * (RADIUS + MARGIN)), "")

            p.translate(RADIUS + MARGIN, RADIUS + MARGIN)
            p.setcolor("fillstroke", "rgb", 0.0, 0.0, 1.0, 0.0)
            p.save()

            ' minute strokes 
            p.setlinewidth(2.0)

            For alpha = 0 To 359 Step 6
                p.rotate(6.0)
                p.moveto(RADIUS, 0.0)
                p.lineto((RADIUS - MARGIN / 3), 0.0)
                p.stroke()
            Next alpha

            p.restore()
            p.save()

            ' 5 minute strokes 
            p.setlinewidth(3.0)
            For alpha = 0 To 359 Step 30
                p.rotate(30.0)
                p.moveto(RADIUS, 0.0)
                p.lineto(RADIUS - MARGIN, 0.0)
                p.stroke()
            Next alpha

            ltime = System.DateTime.Now

            ' draw hour hand 
            p.save()
            p.rotate((-((ltime.Minute / 60.0F) + ltime.Hour - 3.0F) * 30.0F))
            p.moveto(-RADIUS / 10, -RADIUS / 20)
            p.lineto(RADIUS / 2, 0.0F)
            p.lineto(-RADIUS / 10, RADIUS / 20)
            p.closepath()
            p.fill()
            p.restore()

            ' draw minute hand 
            p.save()
            p.rotate((-((ltime.Second / 60.0F) + ltime.Minute - 15.0F) * 6.0F))
            p.moveto(-RADIUS / 10, -RADIUS / 20)
            p.lineto(RADIUS * 0.8F, 0.0F)
            p.lineto(-RADIUS / 10, RADIUS / 20)
            p.closepath()
            p.fill()
            p.restore()

            ' draw second hand 
            p.setcolor("fillstroke", "rgb", 1.0, 0.0, 0.0, 0.0)
            p.setlinewidth(2)
            p.save()
            p.rotate(-((ltime.Second - 15.0F) * 6.0))
            p.moveto(-RADIUS / 5, 0.0F)
            p.lineto(RADIUS, 0.0F)
            p.stroke()
            p.restore()

            ' draw little circle at center 
            p.circle(0, 0, RADIUS / 30)
            p.fill()

            p.restore()

            p.end_page_ext("")
            p.end_document("")

        Catch e As PDFlibException
            ' caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in pdfclock sample:")
            Console.WriteLine("[{0}] {1}: {2}", e.get_errnum(), e.get_apiname(), e.get_errmsg)

        Finally
            If Not p Is Nothing Then
                p.Dispose()
            End If
        End Try

    End Sub
End Class
