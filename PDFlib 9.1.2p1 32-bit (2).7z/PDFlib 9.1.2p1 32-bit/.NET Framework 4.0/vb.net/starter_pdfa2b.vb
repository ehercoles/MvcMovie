'
' $Id$
'
' PDF/A-2b starter:
' Create PDF/A-2b conforming output with layers, transparency and
' PDF/A attachments.
'
' Required software: PDFlib/PDFlib+PDI/PPS 9
' Required data: font file, image file, ICC output intent profile
'                (see www.pdflib.com for output intent ICC profiles)
'

Imports System
Imports System.Text
Imports PDFlib_dotnet


Module starter_pdfa2b
    Sub Main()
        ' This is where the data files are. Adjust as necessary.
        Const searchpath As String = "../../data"

        Dim p As PDFlib_dotnet.PDFlib = Nothing
        Const imagefile As String = "zebra.tif"
        Dim attachments(2) As String
        attachments(0) = "lionel.pdf"
        attachments(1) = "nesrin.pdf"
        Dim attachment_count As Integer = 2
        Dim optlist As String

        Dim font, image, icc, gstate As Integer
        Dim layer_english, layer_german, layer_french, layer_image As Integer
        Dim textflow As Integer
        Dim width, height As Double
        Dim i As Integer

        ' create a new PDFlib object
        p = New PDFlib()

        Try
            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            ' Initially display the layer panel and show the full page
            If (p.begin_document("starter_pdfa2b.pdf", _
                   "openmode=layers viewerpreferences={fitwindow=true} " + _
                   "pdfa=PDF/A-2b") = -1) Then
                Console.WriteLine("Error: {0}\n", p.get_errmsg())
                Return
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_pdfa2b")

            if p.load_iccprofile("sRGB", "usage=outputintent") = -1 Then
                Console.WriteLine("Error: " & p.get_errmsg())
                Console.WriteLine("See www.pdflib.com for output intent ICC profiles." )
                return
            End If

            ' Define the layers, with only English and image layers switched on
            layer_english = p.define_layer("English text", "")
            layer_german = p.define_layer("German text", "defaultstate=false")
            layer_french = p.define_layer("French text", "defaultstate=false")
            layer_image = p.define_layer("Images", "")

            ' Define a radio button relationship for the language layers, so
            ' only one language can be switched on at a time.
            '
            optlist = String.Format("group={{{0} {1} {2}}}", _
                   layer_english, layer_german, layer_french)
            p.set_layer_dependency("Radiobtn", optlist)

            p.begin_page_ext(595, 842, "")

            ' Font embedding is required for PDF/A
            font = p.load_font("LuciduxSans-Oblique", "winansi", "embedding")

            If (font = -1) Then
                Console.WriteLine("Error: {0}\n", p.get_errmsg())
                Return
            End If

            optlist = String.Format("font={0} fontsize=24", font)

            p.begin_layer(layer_english)
            textflow = p.create_textflow( _
                    "PDF/A-2b starter sample with layers, transparency " + _
                    "and attachments", optlist)
            p.fit_textflow(textflow, 50, 650, 550, 700, "")
            p.delete_textflow(textflow)

            p.begin_layer(layer_german)
            textflow = p.create_textflow( _
                    "PDF/A-2b Starter-Beispiel mit Ebenen, Transparenz " + _
                    "und Anlagen", optlist)
            p.fit_textflow(textflow, 50, 650, 550, 700, "")
            p.delete_textflow(textflow)

            p.begin_layer(layer_french)
            textflow = p.create_textflow( _
                    "PDF/A-2b starter exemple avec des calques, " + _
                    "de la transparence et des annexes", optlist)
            p.fit_textflow(textflow, 50, 650, 550, 700, "")
            p.delete_textflow(textflow)

            p.begin_layer(layer_image)

            p.setfont(font, 48)

            image = p.load_image("auto", imagefile, "")

            If (image = -1) Then
                Console.WriteLine("Error: {0}\n", p.get_errmsg())
                Return
            End If

            width = p.info_image(image, "width", "")
            height = p.info_image(image, "height", "")

            ' Place the image on the page and close it
            p.fit_image(image, 0.0, 0.0, "")
            p.close_image(image)

            ' Set transparency in the graphics state
            gstate = p.create_gstate("opacityfill=0.5")
            p.set_gstate(gstate)

            ' Place a transparent diagonal stamp across the image area, in
            ' different colors
            '/
            optlist = String.Format("boxsize={{{0} {1}}} stamp=ll2ur", _
                    width, height)

            p.begin_layer(layer_english)
            p.setcolor("fill", "Lab", 100, 28, 75, 0)
            p.fit_textline("Transparent text", 0, 0, optlist)

            p.begin_layer(layer_german)
            p.setcolor("fill", "Lab", 33.725, 5, -52, 0)
            p.fit_textline("Transparenter Text", 0, 0, optlist)

            p.begin_layer(layer_french)
            p.setcolor("fill", "Lab", 0, 0, 0, 0)
            p.fit_textline("Texte transparent", 0, 0, optlist)

            ' Close all layers
            p.end_layer()

            p.end_page_ext("")

            ' Construct option list with attachment handles.
            ' The attachments must be PDF/A-1 or PDF/A-2 files.
            '/
            Dim optbuf As New StringBuilder()
            optbuf.Append("attachments={")
            For i = 0 To attachment_count - 1 Step 1
                Dim attachment_handle As Integer

                attachment_handle = p.load_asset("Attachment", attachments(i), _
                                    "description={This is a PDF/A attachment}")

                If (attachment_handle = -1) Then
                    Console.WriteLine("Error loading attachment: {0}\n", _
                                p.get_errmsg())
                    Return
                End If

                optbuf.AppendFormat(" {0}", attachment_handle)
            Next

            optbuf.Append("}")
            p.end_document(optbuf.ToString())

        Catch e As PDFlibException
            ' caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred:")
            Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(), _
                    e.get_apiname(), e.get_errmsg())
        Finally
            If Not p Is Nothing Then
                p.Dispose()
            End If
        End Try
    End Sub
End Module
