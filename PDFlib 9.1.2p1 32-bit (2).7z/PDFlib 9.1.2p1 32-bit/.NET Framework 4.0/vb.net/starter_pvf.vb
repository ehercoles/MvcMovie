' $Id$
' PDFlib Virtual File system (PVF):
' Create a PVF file which holds an image or PDF, and import the data from the
' PVF file
'
' This avoids disk access and is especially useful when the same image or PDF
' is imported multiply. For examples, images which sit in a database don't
' have to be written and re-read from disk, but can be passed to PDFlib
' directly in memory. A similar technique can be used for loading other data
' such as fonts, ICC profiles, etc.
'
' Required software: PDFlib/PDFlib+PDI/PPS 9
' Required data: image file
'

Imports System
Imports System.IO
Imports System.Text
Imports PDFlib_dotnet


Module starter_pvf
    Sub Main()
        ' This is where the data files are. Adjust as necessary.'
        Const searchpath As String = "../../data"
        Const  outfile As String = "starter_pvf.pdf"
        Const  title As String = "PDFlib Virtual File System"

        Dim p As PDFlib_dotnet.PDFlib = Nothing
        Dim imagefile As FileStream = Nothing
        Dim filelen, len As Integer

        try 
            p = new PDFlib()
            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            ' Set an output path according to the name of the topic'
            if (p.begin_document(outfile, "") = -1) Then
                Console.WriteLine("Error: " & p.get_errmsg())
                return
            End If

            p.set_info("Creator", "PDFlib Cookbook")
            p.set_info("Title", title)

            ' We just read some image data from a file; to really benefit
            ' from using PVF read the data from a Web site or a database instead
            '
            imagefile = File.Open("../../data/PDFlib-logo.tif", FileMode.Open, FileAccess.Read)
            filelen = imagefile.Seek(0, SeekOrigin.End)
            imagefile.Seek(0, SeekOrigin.Begin)
            Dim imagedata(CInt(filelen)) As Byte
            len = imagefile.Read(imagedata, 0, filelen)
            imagefile.Close()

            p.create_pvf("/pvf/image", imagedata, "")

            ' Load the image from the PVF'
            Dim image As Integer
            image = p.load_image("auto", "/pvf/image", "")
            if (image = -1)  Then
                Console.WriteLine("Error: " & p.get_errmsg())
                return
            End If

            ' Fit the image on page 1'
            p.begin_page_ext(595, 842, "")

            p.fit_image(image, 350, 750, "")

            p.end_page_ext("")

            ' Fit the image on page 2'
            p.begin_page_ext(595, 842, "")

            p.fit_image(image, 350, 50, "")

            p.end_page_ext("")

            ' Delete the virtual file to free the allocated memory'

            p.delete_pvf("/pvf/image")

            p.end_document("")

        Catch e As PDFlibException
            Console.Error.WriteLine("PDFlib exception occurred:")
            Console.Error.WriteLine("[{0}] {1}: {2}", e.get_errnum(), e.get_apiname(), e.get_errmsg)
        Catch e As System.Exception
            Console.Error.WriteLine(e.ToString())
        Finally
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Module
