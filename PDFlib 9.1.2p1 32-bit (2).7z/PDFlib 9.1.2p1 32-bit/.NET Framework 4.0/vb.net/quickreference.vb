' $Id: quickreference.vb
'
' PDFlib client: quickreference example in vb.NET
'

Imports System
Imports System.Text
Imports PDFlib_dotnet

Class quickreference
    Public Shared Sub Main()
        Dim p As PDFlib_dotnet.PDFlib
        Dim manual, page As Integer
        Dim inFile As String
        Dim searchpath As String
        Dim width, height As Integer
        Dim font, row, col, maxrow, maxcol As Integer
        Dim endpage, pageno As Integer
        Dim optlist As New StringBuilder()

        inFile = "reference.pdf"
        ' This is where font/image/PDF input files live. Adjust as necessary.
        searchpath = "../../data"

        maxrow = 2
        maxcol = 2

        width = 500
        height = 770

        p = New PDFlib()

        Try
	    ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            If (p.begin_document("quickreference.pdf", "") = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                End
            End If

            p.set_info("Creator", "quickreference.vb")
            p.set_info("Author", "Rainer Schaaf")
            p.set_info("Title", "mini imposition demo (VB.NET)")

            manual = p.open_pdi_document(inFile, "")
            If (manual = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                End
            End If

            row = 0
            col = 0

            endpage = p.pcos_get_number(manual, "length:pages")

            For pageno = 1 To endpage Step 1
                If (row = 0 And col = 0) Then
                    p.begin_page_ext(width, height, "topdown")
                    font = p.load_font("Helvetica-Bold", "unicode", "")
                    If (font = -1) Then
                        Console.WriteLine("Error: {0}", p.get_errmsg())
                        End
                    End If
                    p.setfont(font, 18)
                    p.set_text_pos(24, 24)
                    p.show("PDFlib Quick Reference")
                End If

                page = p.open_pdi_page(manual, pageno, "")
                If (page = -1) Then
                    Console.WriteLine("Error: {0}", p.get_errmsg())
                    End
                End If

                optlist.Length = 0
                optlist.AppendFormat("scale {0}", 1 / maxrow)
                p.fit_pdi_page(page, width / maxcol * col, (row + 1) * height / maxrow, optlist.ToString())
                p.close_pdi_page(page)

                col = col + 1
                If (col = maxcol) Then
                    col = 0
                    row = row + 1
                End If

                If (row = maxrow) Then
                    row = 0
                    p.end_page_ext("")
                End If
            Next

            ' finish the last partial page
            If (row <> 0 Or col <> 0) Then
                p.end_page_ext("")
            End If

            p.end_document("")
            p.close_pdi_document(manual)

        Catch e As PDFlibException
            ' caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in quickreference sample:")
            Console.WriteLine("[{0}] {1}: {2}", e.get_errnum(), e.get_apiname(), e.get_errmsg)

        Finally
            If Not p Is Nothing Then
                p.Dispose()
            End If
        End Try

    End Sub
End Class

