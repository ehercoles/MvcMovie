' $Id: hello.vb
'
' PDFlib client: hello example in VB.NET
'

Imports System
Imports System.Text
Imports PDFlib_dotnet

Class hello
    Public Shared Sub Main()
        Dim p As PDFlib_dotnet.PDFlib
        Dim font As Integer

        p = New PDFlib()

        Try
            ' This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return")

            If (p.begin_document("hello.pdf", "") = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                End
            End If

            p.set_info("Creator", "hello.vb")
            p.set_info("Author", "Rainer Schaaf")
            p.set_info("Title", "Hello, world (VB.NET)!")

            ' start a new page
            p.begin_page_ext(595, 842, "")

            font = p.load_font("Helvetica-Bold", "unicode", "")
            If (font = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                End
            End If

            p.setfont(font, 24)
            p.set_text_pos(50, 700)
            p.show("Hello, world!")
            p.continue_text("(says .NET/VB)")

            p.end_page_ext("")
            p.end_document("")

        Catch e As PDFlibException
            Console.WriteLine("PDFlib exception occurred in hello sample:")
            Console.WriteLine("[{0}] {1}: {2}", e.get_errnum(), e.get_apiname(), e.get_errmsg)

        Finally
            If Not p Is Nothing Then
                p.Dispose()
            End If
        End Try

    End Sub
End Class
