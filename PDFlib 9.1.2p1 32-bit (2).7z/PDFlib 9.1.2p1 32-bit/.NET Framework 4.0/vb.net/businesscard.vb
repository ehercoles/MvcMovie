' $Id: businesscard.vb
'
' PDFlib client: block processing in vb.NET
'

Imports System
Imports System.Text
Imports PDFlib_dotnet

Structure blockdata
    Public name, value As String

    ' Constructor:
    Public Sub New(ByVal s_name As String, ByVal s_value As String)
        name = s_name
        value = s_value
    End Sub

End Structure

Class businesscard
    Public Shared Sub Main()
        Dim p As PDFlib_dotnet.PDFlib
        Dim i, blockcontainer, page As Integer
        Dim infile As String
        Dim searchpath As String
        Dim data(7) As blockdata
        Dim BLOCKCOUNT As Integer

        data(0) = New blockdata("name", "Victor Kraxi")
        data(1) = New blockdata("business.title", "Chief Paper Officer")
        data(2) = New blockdata("business.address.line1", "17, Aviation Road")
        data(3) = New blockdata("business.address.city", "Paperfield")
        data(4) = New blockdata("business.telephone.voice", "phone +1 234 567-89")
        data(5) = New blockdata("business.telephone.fax", "fax +1 234 567-89")
        data(6) = New blockdata("business.email", "victor@kraxi.com")
        data(7) = New blockdata("business.homepage", "www.kraxi.com")

        BLOCKCOUNT = data.Length

        infile = "boilerplate.pdf"
        ' This is where font/image/PDF input files live. Adjust as necessary.
        '
        ' Note that this directory must also contain the LuciduxSans font
        ' outline and metrics files.
        '
        searchpath = "../../data"

        p = New PDFlib()

        Try
            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")


            If (p.begin_document("businesscard.pdf", "") = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                End
            End If

            p.set_info("Creator", "businesscard.vb")
            p.set_info("Author", "Rainer Schaaf")
            p.set_info("Title", "PDFlib block processing sample (.NET/VB)")

            blockcontainer = p.open_pdi_document(infile, "")
            If (blockcontainer = -1) Then
                Console.WriteLine("Couldn't open input file {0}.", infile)
                End
            End If

            page = p.open_pdi_page(blockcontainer, 1, "")

            If (page = -1) Then
                Console.WriteLine("Couldn't open page 1 in {0}.", infile)
                End
            End If

            p.begin_page_ext(20, 20, "")   ' dummy page size

            ' This will adjust the page size to the block container's size
            p.fit_pdi_page(page, 0, 0, "adjustpage")


            For i = 0 To (BLOCKCOUNT - 1) Step 1
                If (p.fill_textblock(page, data(i).name, data(i).value, "embedding pdiwarning encoding=unicode") = -1) Then
                    Console.WriteLine("Warning: couldn't fill block {0} in {1}", data(i).name, infile)
                End If
            Next

            p.end_page_ext("")
            p.close_pdi_page(page)

            p.end_document("")
            p.close_pdi_document(blockcontainer)

        Catch e As PDFlibException
            ' caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in businesscard sample:")
            Console.WriteLine("[{0}] {1}: {2}", e.get_errnum(), e.get_apiname(), e.get_errmsg)

        Finally
            If Not p Is Nothing Then
                p.Dispose()
            End If
        End Try

    End Sub
End Class
