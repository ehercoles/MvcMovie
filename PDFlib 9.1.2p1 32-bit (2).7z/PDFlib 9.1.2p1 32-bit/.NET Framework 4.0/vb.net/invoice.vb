' $Id$
'
' PDFlib client: invoice generation demo vb.NET
'

Imports System
Imports System.Text
Imports PDFlib_dotnet
Imports Microsoft.VisualBasic

Structure articledata
    Public name As String
    Public price As Double
    Public quantity As Integer

    ' Constructor:
    Public Sub New(ByVal s_name As String, ByVal s_price As Double, ByVal s_quantity As Integer)
        name = s_name
        price = s_price
        quantity = s_quantity
    End Sub
End Structure


Class invoice
    Public Shared Sub Main()
        Dim p As PDFlib

        Dim i, stationery, page, regularfont, boldfont As Integer
        Dim infile As String
        Dim searchpath As String
        Dim left, right As Integer
        Dim ltime As System.DateTime
        Dim fontsize, leading, y As Double
        Dim sum, total As Double
        Dim pagewidth, pageheight As Double
        Dim str As New StringBuilder
        Dim closingtext As String
        Dim data(6) As articledata
        Dim ARTICLECOUNT As Integer
        Dim months(12) As String
        Dim buf As String
        Dim optlist As New StringBuilder
        Dim baseopt As String
        Dim textflow As Integer

        left = 55 : right = 530
        fontsize = 12
        pagewidth = 595 : pageheight = 842

        baseopt = _
        "ruler        {   30 45     275   375   475} " + _
        "tabalignment {right left right right right} " + _
        "hortabmethod ruler fontsize 12 "

        closingtext = _
     "Terms of payment: <fillcolor={rgb 1 0 0}>30 days net. " & _
     "<fillcolor={gray 0}>90 days warranty starting at the day of sale. " & _
     "This warranty covers defects in workmanship only. " & _
     "<fontname=Helvetica-BoldOblique encoding=host>Kraxi Systems, Inc. " & _
     "<resetfont>will, at its option, repair or replace the " & _
     "product under the warranty. This warranty is not transferable. " & _
     "No returns or exchanges will be accepted for wet products."


        months(0) = "January"
        months(1) = "February"
        months(2) = "March"
        months(3) = "April"
        months(4) = "May"
        months(5) = "June"
        months(6) = "July"
        months(7) = "August"
        months(8) = "September"
        months(9) = "October"
        months(10) = "November"
        months(11) = "December"

        data(0) = New articledata("Super Kite", 20, 2)
        data(1) = New articledata("Turbo Flyer", 40, 5)
        data(2) = New articledata("Giga Trash", 180, 1)
        data(3) = New articledata("Bare Bone Kit", 50, 3)
        data(4) = New articledata("Nitty Gritty", 20, 10)
        data(5) = New articledata("Pretty Dark Flyer", 75, 1)
        data(6) = New articledata("Free Gift", 0, 1)

        ARTICLECOUNT = data.Length

        infile = "stationery.pdf"
        ' This is where font/image/PDF input files live. Adjust as necessary.
        searchpath = "../../data"

	p = New PDFlib
        Try

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            p.begin_document("invoice.pdf", "")

            p.set_info("Creator", "invoice.vb.aspx")
            p.set_info("Author", "Rainer Schaaf")
            p.set_info("Title", "PDFlib invoice generation demo (ASP.NET/VB)")


            stationery = p.open_pdi_document(infile, "")
            If (stationery = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                Return
            End If

            page = p.open_pdi_page(stationery, 1, "")
            If (page = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                Return
            End If

            boldfont = p.load_font("Helvetica-Bold", "unicode", "")
            if (boldfont = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                End
            End If
            regularfont = p.load_font("Helvetica", "unicode", "")
            If (regularfont = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                End
            End If
            leading = fontsize + 2


            ' Establish coordinates with the origin in the upper left corner.
            p.begin_page_ext(pagewidth, pageheight, "topdown")

            p.fit_pdi_page(page, 0, pageheight, "")
            p.close_pdi_page(page)

            p.setfont(regularfont, fontsize)

            ' Print the address
            y = 170
            p.set_text_option("leading=" + leading.ToString())

            p.show_xy("John Q. Doe", left, y)
            p.continue_text("255 Customer Lane")
            p.continue_text("Suite B")
            p.continue_text("12345 User Town")
            p.continue_text("Everland")

            ' Print the header and date

            p.setfont(boldfont, fontsize)
            y = 300
            p.show_xy("INVOICE", left, y)


            ltime = System.DateTime.Now

            str.Length = 0
            str.AppendFormat("{0} {1}, {2}", months(ltime.Month - 1), ltime.Day, ltime.Year)

            p.fit_textline(str.ToString(), right, y, "position {100 0}")

            ' Print the invoice header line
            p.setfont(boldfont, fontsize)

            ' "position {0 0}" is left-aligned, "position {100 0}" right-aligned
            y = 370
            buf = ChrW(9) & "ITEM" & ChrW(9) & "DESCRIPTION" & ChrW(9) & "QUANTITY" & ChrW(9) & "PRICE" & ChrW(9) & "AMOUNT"
            optlist.Length = 0 : optlist.AppendFormat("{0} font {1}", baseopt, boldfont)

            textflow = p.create_textflow(buf, optlist.ToString())
            
            If (textflow = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                Return
            End If
            
            p.fit_textflow(textflow, left, y - leading, right, y, "")
            p.delete_textflow(textflow)

            ' Print the article list

            p.setfont(regularfont, fontsize)
            y += 2 * leading
            total = 0

            optlist.Length = 0 : optlist.AppendFormat("{0} font {1}", baseopt, regularfont)

            For i = 0 To (ARTICLECOUNT - 1) Step 1
                str.Length = 0 : str.AppendFormat("{0:X}{1}", ChrW(9), i + 1)
                str.AppendFormat("{0:X}{1}", ChrW(9), data(i).name)
                str.AppendFormat("{0:X}{1}", ChrW(9), data(i).quantity)
                str.AppendFormat("{0:X}{1:F2}", ChrW(9), data(i).price)

                sum = data(i).price * data(i).quantity
                str.AppendFormat("{0:X}{1:F2}", ChrW(9), sum)

                textflow = p.create_textflow(str.ToString(), optlist.ToString())
                
                If (textflow = -1) Then
                    Console.WriteLine("Error: {0}", p.get_errmsg())
                    Return
                End If
            
                p.fit_textflow(textflow, left, y - leading, right, y, "")
                p.delete_textflow(textflow)

                y += leading
                total += sum
            Next

            y += leading
            p.setfont(boldfont, fontsize)
            str.Length = 0 : str.AppendFormat("{0:F2}", total)
            p.fit_textline(str.ToString(), right, y, "position {100 0}")

            ' Print the closing text

            y += 5 * leading

            optlist.Length = 0 : optlist.AppendFormat("alignment=justify leading=120% ")
            optlist.AppendFormat("fontname=Helvetica fontsize=12 encoding=unicode")

            textflow = p.create_textflow(closingtext, optlist.ToString())

            If (textflow = -1) Then
                Console.WriteLine("Error: {0}", p.get_errmsg())
                Return
            End If

            p.fit_textflow(textflow, left, y + 6 * leading, right, y, "")
            p.delete_textflow(textflow)

            p.end_page_ext("")
            p.end_document("")
            p.close_pdi_document(stationery)

        Catch e As PDFlibException
            ' caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in invoice sample:")
            Console.WriteLine("[{0}] {1}: {2}", e.get_errnum(), e.get_apiname(), e.get_errmsg)

        Finally
            If Not p Is Nothing Then
                p.Dispose()
            End If
        End Try

    End Sub
End Class
