// $Id$
//
// PDF/X-3 starter:
// Create PDF/X-3 conforming output
//
// Required software: PDFlib/PDFlib+PDI/PPS 9
// Required data: font file, image file, ICC profile
//                (see www.pdflib.com for output intent ICC profiles)
//

using System;
using System.Text;
using PDFlib_dotnet;

class starter_pdfx3 {
    static void Main(string[] args) {
        /* This is where the data files are. Adjust as necessary.*/
        String searchpath = "../../data";

        PDFlib p;
        String imagefile = "nesrin.jpg";

        int font, image, spot, icc;

        p = new PDFlib();

        try
        {
            // This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return");

            // Set the search path for fonts and PDF files 
            p.set_option("SearchPath={{" + searchpath + "}}");

            if (p.begin_document("starter_pdfx3.pdf", "pdfx=PDF/X-3:2003") == -1)
                    throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib starter sample");
            p.set_info("Title", "starter_pdfx3");

            if (p.load_iccprofile("ISOcoated_v2_eci.icc", "usage=outputintent") == -1) {
                throw new Exception( "Error: " +  p.get_errmsg() + "\n" 
                + "See www.pdflib.com for output intent ICC profiles.\n");
            }


            p.begin_page_ext(595, 842, "");

            /* Font embedding is required for PDF/X */
            font = p.load_font("LuciduxSans-Oblique", "unicode", "embedding");
            if (font == -1)
                throw new Exception("Error: " + p.get_errmsg());
            p.setfont(font, 24);

            spot = p.makespotcolor("PANTONE 123 C");
            p.setcolor("fill", "spot", spot, 1.0, 0.0, 0.0);
            p.fit_textline("PDF/X-3:2003 starter", 50, 700, "");

            /* The RGB image below needs an ICC profile; we use sRGB. */
            icc = p.load_iccprofile("sRGB", "");
            if (icc == -1)
                throw new Exception("Error: " + p.get_errmsg());

            image = p.load_image("auto", imagefile, "iccprofile=" + icc);

            if (image == -1)
                    throw new Exception("Error: " + p.get_errmsg());

            p.fit_image(image, 0.0, 0.0, "scale=0.5");

            p.end_page_ext("");

            p.end_document("");

        }

        catch (PDFlibException e)
        {
            // caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred:");
            Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(),
                    e.get_apiname(), e.get_errmsg());
        } finally {
            if (p != null) {
                p.Dispose();
            }
        }
    }
}
