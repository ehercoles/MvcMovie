// $Id$
// Starter sample for fallback fonts
//
// Required software: PDFlib/PDFlib+PDI/PPS 9
// Required data: suitable fonts, Japanese CMaps
//

using System;
using System.Text;
using PDFlib_dotnet;

struct testcase {
    public string usecase;
    public string fontname;
    public string encoding;
    public string fallbackoptions;
    public string text;
    // Constructor
    public testcase(string usecase, string fontname, string encoding, string fallbackoptions, string text)
    {
        this.usecase = usecase;
        this.fontname = fontname;
        this.encoding = encoding;
        this.fallbackoptions = fallbackoptions;
        this.text = text;
    }
};

class starter_fallback {
  static int Main(string[] args) {

        /* This is where the data files are. Adjust as necessary. */
        string searchpath = "../../data";
        string outfile = "starter_fallback.pdf";

        StringBuilder optlist = new StringBuilder();;
        PDFlib p;
        int row, col, table, test;
        double llx= 50, lly=50, urx=800, ury=550;
        string result;

        string[] header = {
            "Use case",
            "Option list for the 'fallbackfonts' option",
            "Base font",
            "With fallback font"
        };
        int MAXCOL = header.Length;

        testcase[] testcases = {
          // Add Euro glyph to an encoding which doesn't support it
          new testcase("Extend 8-bit encoding",
          "Helvetica",
          "iso8859-1",
          "{fontname=Helvetica encoding=unicode forcechars=euro}",
          //Reference Euro glyph by name (since it is missing from the encoding)
           "123&euro;"),
          new testcase("Use Euro glyph from another font",
          "Courier",
          "winansi",
          "{fontname=Helvetica encoding=unicode forcechars=euro textrise=-5%}",
           "123&euro;"),
          new testcase("Enlarge all glyphs in a font",
          "Times-Italic",
          "winansi",
          // Enlarge all glyphs to better match other fonts of the same point size
          "{fontname=Times-Italic encoding=unicode forcechars={U+0020-U+00FF} " +
          "fontsize=120%}",
           "font size"),
          new testcase("Add enlarged pictogram",
          "Times-Roman",
          "unicode",
          // pointing hand pictogram
          "{fontname=ZapfDingbats encoding=unicode forcechars=.a12 " +
          "fontsize=150% textrise=-15%}",
      "Bullet symbol: &.a12;"),
          new testcase("Add enlarged symbol glyph",
          "Times-Roman",
          "unicode",
          "{fontname=Symbol encoding=unicode forcechars=U+2663 fontsize=125%}",
           "Club symbol: &#x2663;"),
          //Greek characters missing in the font will be pulled from Symbol font
          new testcase("Add Greek characters to Latin font",
          "Times-Roman",
          "unicode",
          "{fontname=Symbol encoding=unicode}",
           "Greek text: &#x039B;&#x039F;&#x0393;&#x039F;&#x03A3;"),
          // Font with end-user defined character (EUDC)
          new testcase("Gaiji with EUDC font",
          "KozMinProVI-Regular",
          "unicode",
          "{fontname=EUDC encoding=unicode forcechars=U+E000 fontsize=140% " +
          "textrise=-20%}",
           "Gaiji: &#xE000;"),
          // SING fontlet containing a single gaiji character
          new testcase("Gaiji with SING font",
          "KozMinProVI-Regular",
          "unicode",
          "{fontname=PDFlibWing encoding=unicode forcechars=gaiji}",
           "Gaiji: &#xE000;"),
          new testcase( "Replace Latin characters in CJK font",
          "KozMinProVI-Regular",
          "unicode",
          "{fontname=Courier-Bold encoding=unicode forcechars={U+0020-U+007E}}",
           "Latin and &#x65E5;&#x672C;&#x8A9E;"),
          // Requires "Unicode BMP Fallback SIL" font in fallback.ttf
          // Identify missing glyphs caused by workflow problems
          new testcase("Identify missing glyphs",
          "Times-Roman",
          "unicode",
          "{fontname=fallback encoding=unicode}",
          //deliberately use characters which are not available in the base font
           "Missing glyphs: &#x1234; &#x672C; &#x8A9E;"),
    };
    int n_testcases = testcases.Length;

    /* create a new PDFlib object */
    p = new PDFlib();

    try {
        
        /* This means that formatting and other errors will raise an
         * exception. This simplifies our sample code, but is not
         * recommended for production code.
         */

        p.set_option("errorpolicy=exception");

        // Set the search path for fonts and PDF files 
        p.set_option("SearchPath={{" + searchpath + "}} glyphcheck=replace charref=true");


        /* Set an output path according to the name of the topic */
        if (p.begin_document(outfile, "") == -1) {
            Console.WriteLine("Error: {0}\n", p.get_errmsg());
            return(2);
        }

        p.set_info("Creator", "PDFlib starter sample");
        p.set_info("Title", "starter_fallback");

        /* Start Page */
        p.begin_page_ext(0, 0, "width=a4.height height=a4.width");

        table = -1;

        /* Table header */
        for (row=1, col=1; col <= MAXCOL; col++)
        {
            optlist.Length = 0;
            optlist.Append("fittextline={fontname=Helvetica-Bold " +
                "encoding=unicode fontsize=11} margin=4");
            table = p.add_table_cell(table, col, row, header[col-1],
                    optlist.ToString());
        }

        /* Create fallback samples, one use case per row */
        for (row=2, test=0; test < n_testcases; row++, test++)
        {
            col=1;

            /* Column 1: description of the use case */
            optlist.Length = 0;
            optlist.Append("fittextline={fontname=Helvetica " +
                    "encoding=unicode fontsize=11} margin=4");
            table = p.add_table_cell(table, col++, row,
                testcases[test].usecase, optlist.ToString());

            /* Column 2: reproduce option list literally */
            optlist.Length = 0;
            optlist.Append("fittextline={fontname=Helvetica " +
                    "encoding=unicode fontsize=10} margin=4");
            table = p.add_table_cell(table, col++, row,
                testcases[test].fallbackoptions, optlist.ToString());

            /* Column 3: text with base font */
            optlist.Length = 0;
            optlist.Append("fittextline={fontname=");
            optlist.AppendFormat("{0}", testcases[test].fontname);
            optlist.Append(" encoding=");
            optlist.AppendFormat("{0}", testcases[test].encoding);
            optlist.Append(" fontsize=11 replacementchar=? } margin=4");
            table = p.add_table_cell(table, col++, row,
                        testcases[test].text, optlist.ToString());

            /* Column 4: text with base font and fallback fonts */
            optlist.Length = 0;
            optlist.Append("fittextline={fontname=");
            optlist.AppendFormat("{0}", testcases[test].fontname);
            optlist.Append(" encoding=");
            optlist.AppendFormat("{0}", testcases[test].encoding);
            optlist.Append(" fontsize=11 fallbackfonts={");
            optlist.AppendFormat("{0}", testcases[test].fallbackoptions);
            optlist.Append("}} margin=4");
            table = p.add_table_cell(table, col++, row,
               testcases[test].text, optlist.ToString());
        }

        /* Place the table */
        optlist.Length = 0;
        optlist.Append("header=1 fill={{area=rowodd " +
            "fillcolor={gray 0.9}}} stroke={{line=other}} ");
        result = p.fit_table(table, llx, lly, urx, ury, optlist.ToString());

        if (result == "_error")
        {
            Console.WriteLine("Couldn't place table: {0}\n",p.get_errmsg());
            return(2);
        }

        p.end_page_ext("");
        p.end_document("");
    }

    catch (PDFlibException e)
    {
        // caught exception thrown by PDFlib
        Console.WriteLine("PDFlib exception occurred:");
        Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(),
                e.get_apiname(), e.get_errmsg());
    } finally {
        if (p != null) {
            p.Dispose();
        }
    }
    return(0);
  }
}
