// $Id$
//
// PDF/A-1b starter:
// Create PDF/A-1b conforming output
// 
// Required software: PDFlib/PDFlib+PDI/PPS 9
// Required data: font file, image file

//

using System;
using System.Text;
using PDFlib_dotnet;


class starter_pdfa1b 
{
    static void Main(string[] args) 
    {
        /* This is where the data files are. Adjust as necessary. */
        string searchpath = "../../data";

        PDFlib p;
        string imagefile = "nesrin.jpg";

        int font;
        int image;

        p = new PDFlib();

        try     
        {
            // This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return");

            // Set the search path for fonts and PDF files 
            p.set_option("SearchPath={{" + searchpath + "}}");

            /* PDF/A-1a requires Tagged PDF */
            if (p.begin_document("starter_pdfa1b.pdf", "pdfa=PDF/A-1b:2005")
                    == -1)
                    throw new Exception("Error: " + p.get_errmsg());

            /*
             * We use sRGB as output intent since it allows the color
             * spaces CIELab, ICC-based, grayscale, and RGB.
             *
             * If you need CMYK color you must use a CMYK output profile.
             */

            if (p.load_iccprofile("sRGB", "usage=outputintent") == -1){
                throw new Exception("Error: " + p.get_errmsg() + "\n" +
                    "See www.pdflib.com for output intent ICC profiles.");
            }

            p.set_info("Creator", "PDFlib starter sample");
            p.set_info("Title", "starter_pdfa1b");

            p.begin_page_ext(595, 842, "");

            /* Font embedding is required for PDF/A */
            font = p.load_font("LuciduxSans-Oblique", "unicode", "embedding");
            if (font == -1)
                throw new Exception("Error: " + p.get_errmsg());
            p.setfont(font, 24);

            p.fit_textline("PDF/A-1b:2005 starter", 50, 700, "");

            /* We can use an RGB image since we already supplied an
             * output intent profile.
             */
            image = p.load_image("auto", imagefile, "");

            if (image == -1)
                    throw new Exception("Error: " + p.get_errmsg());

            /* Place the image at the bottom of the page */
            p.fit_image(image, 0.0, 0.0, "scale=0.5");

            p.end_page_ext("");
	    p.close_image(image);

            p.end_document("");

        }
        catch (PDFlibException e)
        {
            // caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred:");
            Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(),
                    e.get_apiname(), e.get_errmsg());
        } 
        finally 
        {
            if (p != null) 
            {
                    p.Dispose();
            }
        }
    }
}
