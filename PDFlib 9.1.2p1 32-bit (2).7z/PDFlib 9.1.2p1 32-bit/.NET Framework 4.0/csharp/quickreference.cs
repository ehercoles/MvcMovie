// $Id$
//
// PDFlib+PDI client: mini imposition demo
//

using System;
using System.Text;
using PDFlib_dotnet;

class quickreference {
    static void Main(string[] args)
    {
        PDFlib p;
        int manual, page;
        int font, row, col;
        const int maxrow = 2;
        const int maxcol = 2;
        StringBuilder optlist = new StringBuilder();
        double endpage;
        const float width = 500, height = 770;
        int pageno;
        string infile = "reference.pdf";
        // This is where font/image/PDF input files live. Adjust as necessary.
        string searchpath = "../../data";

        p = new PDFlib();

        try
        {
            // This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return");

            // Set the search path for fonts and PDF files 
            p.set_option("SearchPath={{" + searchpath + "}}");

            if (p.begin_document("quickreference.pdf", "") == -1) {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            p.set_info("Creator", "quickreference.cs");
            p.set_info("Author", "Rainer Schaaf");
            p.set_info("Title", "mini imposition demo (.NET/C#)");

            manual = p.open_pdi_document(infile, "");
            if (manual == -1) {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            row = 0;
            col = 0;

            endpage = p.pcos_get_number(manual, "length:pages");

            for (pageno = 1; pageno <= endpage; pageno++) {
                if (row == 0 && col == 0) {
                    p.begin_page_ext(width, height, "topdown");
                    font = p.load_font("Helvetica-Bold", "unicode", "");
                    if (font == -1)
                    {
                        Console.WriteLine("Error: {0}\n", p.get_errmsg());
                        return;
                    }
                    p.setfont(font, 18);
                    p.set_text_pos(24, 24);
                    p.show("PDFlib Quick Reference");
                }

                page = p.open_pdi_page(manual, pageno, "");

                if (page == -1) {
                    Console.WriteLine("Error: {0}\n", p.get_errmsg());
                    return;
                }

                optlist.Length = 0;
                optlist.AppendFormat("scale {0}",(float) 1/maxrow);
                p.fit_pdi_page(page, (float)width/maxcol*col, (float)(row + 1) * height/maxrow, optlist.ToString());
                p.close_pdi_page(page);

                col++;
                if (col == maxcol) {
                    col = 0;
                    row++;
                }
                if (row == maxrow) {
                    row = 0;
                    p.end_page_ext("");
                }
            }

            // finish the last partial page
            if (row != 0 || col != 0)
                    p.end_page_ext("");

            p.end_document("");         
            p.close_pdi_document(manual);
        }

        catch (PDFlibException e)
        {
            // caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in quickreference sample:");
            Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(),
                    e.get_apiname(), e.get_errmsg());
        } finally {
            if (p != null) {
                p.Dispose();
            }
        }
    }
}
