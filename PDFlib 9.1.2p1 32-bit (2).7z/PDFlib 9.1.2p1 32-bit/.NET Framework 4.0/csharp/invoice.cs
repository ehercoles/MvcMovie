// $Id$
//
// PDFlib/PDI client: invoice generation demo in C#
//

using System;
using System.Text;
using PDFlib_dotnet;

struct articledata 
{
    public string name;
    public float price;
    public int quantity;

    // Constructor:
    public articledata(string name, float price, int quantity) 
    {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
}
class invoice {
    static void Main(string[] args) {
        PDFlib p;
        int i, stationery, page, regularfont, boldfont;
        string infile = "stationery.pdf";
        // This is where font/image/PDF input files live. Adjust as necessary.
        string searchpath = "../../data";
        const int left = 55;
        const int right = 530;
        System.DateTime ltime;
        StringBuilder date = new StringBuilder();
        float fontsize = 12, leading, y;
        float sum, total;
        float pagewidth = 595, pageheight = 842;
        // StringBuilder buf = new StringBuilder();
        StringBuilder str = new StringBuilder();
        StringBuilder optlist = new StringBuilder();
        int textflow;

        string baseopt = 
                "ruler        {   30 45     275   375   475} " + 
                "tabalignment {right left right right right} " + 
                "hortabmethod ruler fontsize 12 ";

        string closingtext = 
        "Terms of payment: <fillcolor={rgb 1 0 0}>30 days net. " +
        "<fillcolor={gray 0}>90 days warranty starting at the day of sale. " +
        "This warranty covers defects in workmanship only. " +
        "<fontname=Helvetica-BoldOblique encoding=host>Kraxi Systems, Inc. " +
        "<resetfont>will, at its option, repair or replace the " +
        "product under the warranty. This warranty is not transferable. " +
        "No returns or exchanges will be accepted for wet products.";

        articledata[] data = {
            new articledata( "Super Kite",  20, 2),
            new articledata( "Turbo Flyer", 40, 5),
            new articledata( "Giga Trash", 180, 1),
            new articledata( "Bare Bone Kit", 50, 3),
            new articledata( "Nitty Gritty", 20, 10),
            new articledata( "Pretty Dark Flyer", 75, 1),
            new articledata( "Free Gift", 0, 1),
        };
        int ARTICLECOUNT = data.Length;

        string[] months = { "January", "February", "March", "April", 
                            "May", "June", "July", "August", "September", 
                            "October", "November", "December" };

        p = new PDFlib();

        try     
        {
            // This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return");

            // Set the search path for fonts and PDF files 
            p.set_option("SearchPath={{" + searchpath + "}}");

            if (p.begin_document("invoice.pdf", "") == -1) {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            p.set_info("Creator", "invoice.cs");
            p.set_info("Author", "Rainer Schaaf");
            p.set_info("Title", "PDFlib invoice generation demo (.NET/C#)");


            stationery = p.open_pdi_document(infile, "");
            if (stationery == -1)
            {
                Console.WriteLine("Error: {0}", p.get_errmsg());
                return;
            }

            page = p.open_pdi_page(stationery, 1, "");
            if (page == -1)
            {
                Console.WriteLine("Error: {0}", p.get_errmsg());
                return;
            }

            boldfont = p.load_font("Helvetica-Bold", "unicode", "");
            if (boldfont == -1) {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }
            regularfont = p.load_font("Helvetica", "unicode", "");
            if (regularfont == -1)
            {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }
            leading = fontsize + 2;


            // Establish coordinates with the origin in the upper left corner.
            p.begin_page_ext(pagewidth, pageheight, "topdown");

            p.fit_pdi_page(page, 0, pageheight, "");
            p.close_pdi_page(page);

            p.setfont(regularfont, fontsize);

            // Print the address
            y = 170;
            p.set_text_option("leading=" + leading);

            p.show_xy("John Q. Doe", left, y);
            p.continue_text("255 Customer Lane");
            p.continue_text("Suite B");
            p.continue_text("12345 User Town");
            p.continue_text("Everland");

            // Print the header and date

            p.setfont(boldfont, fontsize);
            y = 300;
            p.show_xy("INVOICE", left, y);

            ltime = System.DateTime.Now;
            str.Length = 0;
            str.AppendFormat("{0} {1}, {2}", months[ltime.Month-1], ltime.Day, ltime.Year);

            p.fit_textline(str.ToString(), right, y, "position {100 0}");

            // Print the invoice header line
            p.setfont(boldfont, fontsize);

            // "position {0 0}" is left-aligned, "position {100 0}" right-aligned
            y = 370;
            str.Length = 0;
            str.AppendFormat("{0:X}{1}", (char)(9), "ITEM");
            str.AppendFormat("{0:X}{1}", (char)(9), "DESCRIPTION");
            str.AppendFormat("{0:X}{1}", (char)(9), "QUANTITY");
            str.AppendFormat("{0:X}{1}", (char)(9), "PRICE");
            str.AppendFormat("{0:X}{1}", (char)(9), "AMOUNT");

            optlist.Length = 0;
            optlist.AppendFormat("{0} font {1}", baseopt, boldfont);

            textflow = p.create_textflow(str.ToString(), optlist.ToString());

            if (textflow == -1)
            {
                Console.WriteLine("Error: {0}", p.get_errmsg());
                return;
            }

            p.fit_textflow(textflow, left, y - leading, right, y, "");
            p.delete_textflow(textflow);

            // Print the article list

            p.setfont(regularfont, fontsize);
            y += 2 * leading;
            total = 0;

            optlist.Length = 0;
            optlist.AppendFormat("{0} font {1}", baseopt, regularfont);

            for (i = 0; i < ARTICLECOUNT; i++) 
            {
                str.Length = 0;
                str.AppendFormat("{0:X}{1}", (char)(9), i + 1);
                str.AppendFormat("{0:X}{1}", (char)(9), data[i].name);
                str.AppendFormat("{0:X}{1}", (char)(9), data[i].quantity);
                str.AppendFormat("{0:X}{1:F2}", (char)(9), data[i].price);

                sum = data[i].price * data[i].quantity;
                str.AppendFormat("{0:X}{1:F2}", (char)(9), sum);

                textflow = p.create_textflow(str.ToString(), optlist.ToString());

                if (textflow == -1)
                {
                    Console.WriteLine("Error: {0}", p.get_errmsg());
                    return;
                }

                p.fit_textflow(textflow, left, y - leading, right, y, "");
                p.delete_textflow(textflow);

                y += leading;
                total += sum;
            }

            y += leading;
            p.setfont(boldfont, fontsize);
            str.Length = 0;
            str.AppendFormat("{0:F2}", total);
            p.fit_textline(str.ToString(), right, y, "position {100 0}");

            // Print the closing text

            y += 5 * leading;

            optlist.Length = 0;
            optlist.AppendFormat("alignment=justify leading=120% ");
            optlist.AppendFormat("fontname=Helvetica fontsize=12 encoding=unicode");

            textflow = p.create_textflow(closingtext, optlist.ToString());

            if (textflow == -1)
            {
                Console.WriteLine("Error: {0}", p.get_errmsg());
                return;
            }

            p.fit_textflow(textflow, left, y + 6 * leading, right, y, "");
            p.delete_textflow(textflow);

            p.end_page_ext("");
            p.end_document("");
            p.close_pdi_document(stationery);
        }
        catch (PDFlibException e)
        {
            // caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in invoice sample:");
            Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(),
                    e.get_apiname(), e.get_errmsg());
        } finally {
            if (p != null) {
                p.Dispose();
            }
        }
    }
}
