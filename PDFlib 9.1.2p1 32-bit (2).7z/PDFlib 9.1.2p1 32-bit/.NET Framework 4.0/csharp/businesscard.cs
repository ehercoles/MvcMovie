// $Id$
//
// PDFlib client:  block processing example in C#
//

using System;
using System.Text;
using PDFlib_dotnet;

struct blockdata
{
    public string name, value;

    // Constructor:
    public blockdata(string name, string value)
    {
        this.name = name;
        this.value = value;
    }
}

class businesscard {
    static void Main(string[] args)
    {
        PDFlib p;
        int i, blockcontainer, page;
        string infile = "boilerplate.pdf";

        // This is where font/image/PDF input files live. Adjust as necessary.
        //
        // Note that this directory must also contain the LuciduxSans font
        // outline and metrics files.
        //
        string searchpath = "../../data";

        blockdata[] data = {
             new blockdata( "name",                    "Victor Kraxi" ),
             new blockdata( "business.title",          "Chief Paper Officer" ),
             new blockdata( "business.address.line1",  "17, Aviation Road" ),
             new blockdata( "business.address.city",   "Paperfield" ),
             new blockdata( "business.telephone.voice","phone +1 234 567-89" ),
             new blockdata( "business.telephone.fax",  "fax +1 234 567-89" ),
             new blockdata( "business.email",          "victor@kraxi.com" ),
             new blockdata( "business.homepage",       "www.kraxi.com" )
        };
        int BLOCKCOUNT = data.Length;

        p = new PDFlib();

        try
        {
            if (p.begin_document("businesscard.pdf", "") == -1) {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            // This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return");

            // Set the search path for fonts and PDF files 
            p.set_option("SearchPath={{" + searchpath + "}}");

            p.set_info("Creator", "businesscard.cs");
            p.set_info("Author", "Rainer Schaaf");
            p.set_info("Title", "PDFlib block processing sample (.NET/C#)");

            blockcontainer = p.open_pdi_document(infile, "");
            if (blockcontainer == -1) {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            page = p.open_pdi_page(blockcontainer, 1, "");

            if (page == -1) {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            p.begin_page_ext(20, 20, "");   // dummy page size

            // This will adjust the page size to the block container's size
            p.fit_pdi_page(page, 0, 0, "adjustpage");

            // Fill all text blocks with dynamic data
            for (i = 0; i < BLOCKCOUNT; i++)
            {
                if (p.fill_textblock(page, data[i].name, data[i].value,
                        "embedding pdiwarning encoding=unicode") == -1)
                {
                    Console.WriteLine("Warning: {0}\n", p.get_errmsg());
                }
            }

            p.end_page_ext("");
            p.close_pdi_page(page);

            p.end_document("");
            p.close_pdi_document(blockcontainer);

        }

        catch (PDFlibException e)
        {
            // caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in businesscard sample:");
            Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(),
                    e.get_apiname(), e.get_errmsg());
        } finally {
            if (p != null) {
                p.Dispose();
            }
        }
    }
}
