// $Id$
//
// PDFlib client: pdfclock example in C#
//

using System;
using PDFlib_dotnet;

class pdfclock {
    static void Main(string[] args) {
        PDFlib p;
        System.DateTime ltime;
        const float RADIUS = 200.0F;
        const float MARGIN = 20.0F;
        float alpha;

        p = new PDFlib();

        try
        {
            // This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return");

            if (p.begin_document("pdfclock.pdf", "") == -1) {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            p.set_info("Creator", "pdfclock.cs");
            p.set_info("Author", "Rainer Schaaf");
            p.set_info("Title", "PDF clock (.NET/C#)!");

            p.begin_page_ext((float) (2 * (RADIUS + MARGIN)),
                    (float) (2 * (RADIUS + MARGIN)), "");

            p.translate(RADIUS + MARGIN, RADIUS + MARGIN);
            p.setcolor("fillstroke", "rgb", 0.0F, 0.0F, 1.0F, 0.0F);
            p.save();

            /* minute strokes */
            p.setlinewidth(2.0F);
            for (alpha = 0; alpha < 360; alpha += 6) {
                p.rotate(6.0F);
                p.moveto(RADIUS, 0.0F);
                p.lineto((float) (RADIUS-MARGIN/3), 0.0F);
                p.stroke();
            }

            p.restore();
            p.save();

            /* 5 minute strokes */
            p.setlinewidth(3.0F);
            for (alpha = 0; alpha < 360; alpha += 30) {
                p.rotate(30.0F);
                p.moveto(RADIUS, 0.0F);
                p.lineto(RADIUS-MARGIN, 0.0F);
                p.stroke();
            }

            ltime = System.DateTime.Now;

            /* draw hour hand */
            p.save();
            p.rotate((float)(-((ltime.Minute/60.0F) + ltime.Hour - 3.0F) * 30.0F));
            p.moveto(-RADIUS/10, -RADIUS/20);
            p.lineto(RADIUS/2, 0.0F);
            p.lineto(-RADIUS/10, RADIUS/20);
            p.closepath();
            p.fill();
            p.restore();

            /* draw minute hand */
            p.save();
            p.rotate((float) (-((ltime.Second/60.0F) + ltime.Minute - 15.0F)*6.0F));
            p.moveto(-RADIUS/10, -RADIUS/20);
            p.lineto(RADIUS * 0.8F, 0.0F);
            p.lineto(-RADIUS/10, RADIUS/20);
            p.closepath();
            p.fill();
            p.restore();

            /* draw second hand */
            p.setcolor("fillstroke", "rgb", 1.0F, 0.0F, 0.0F, 0.0F);
            p.setlinewidth(2);
            p.save();
            p.rotate((float) -((ltime.Second - 15.0F) * 6.0F));
            p.moveto(-RADIUS/5, 0.0F);
            p.lineto(RADIUS, 0.0F);
            p.stroke();
            p.restore();

            /* draw little circle at center */
            p.circle(0, 0, (float) RADIUS/30);
            p.fill();

            p.restore();

            p.end_page_ext("");
            p.end_document("");
        }

        catch (PDFlibException e)
        {
            // caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in pdfclock sample:");
            Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(),
                    e.get_apiname(), e.get_errmsg());
        } finally {
            if (p != null) {
                p.Dispose();
            }
        }
    }
}
