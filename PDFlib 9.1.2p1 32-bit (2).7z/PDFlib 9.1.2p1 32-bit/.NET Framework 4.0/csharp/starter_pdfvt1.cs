// $Id$
//
// Starter sample for PDF/VT-1
// Create a large number of invoices in a single PDF and make use of
// the following PDF/VT-1 features:
// - create a document part (DPart) hierarchy
// - assign PDF/VT scope attributes to images and imported PDF pages
// - add document part metadata (DPM) to the DPart root node and all page nodes
//
// Required software: PDFlib+PDI/PPS 9
// Required data: PDF background, fonts, several raster images

using System;
using System.Text;
using System.Collections;
using PDFlib_dotnet;

struct articledata_s
{
    public string name;
    public float price;

    // Constructor:
    public articledata_s(string name, float price) 
    {
        this.name = name;
        this.price = price;
    }
}

struct addressdata_s
{
    public string firstname;
    public string lastname;
    public string flat;
    public string street;
    public string city;

    // Constructor:
    public addressdata_s(string firstname, string lastname, string flat,
                                string street, string city) 
    {
        this.firstname = firstname;
        this.lastname = lastname;
        this.flat = flat;
        this.street = street;
        this.city = city;
    }
}

class starter_pdfvt1
{
    const int MATRIXROWS = 32;
    const int MATRIXDATASIZE = (4 * MATRIXROWS);

    static void Main(string[] args)
    {   
        PDFlib p;
        const int MAXRECORD = 100;
        int i, stationery, page;
        int record;
        int barcodeimage;
        const string stationeryfilename = "stationery_pdfx4p.pdf";
        const string salesrepfilename = "sales_rep{0}.jpg";
        const string fontname = "LinLibertine_R";

        // This is where font/image/PDF input files live. Adjust as necessary.
        string searchpath = "../../data";

        const double left = 55;
        const double right = 530;
        const double bottom = 822;

        double fontsize = 12, leading, x, y;

        String buf;
        String optlist;
        String fontoptions;

        const string closingtext =
            "Terms of payment: <save fillcolor={cmyk 0 1 1 0}>30 days net<restore>. " +
            "90 days warranty starting at the day of sale. " +
            "This warranty covers defects in workmanship only. " +
            "Kraxi Systems, Inc. will, at its option, repair or replace the " +
            "product under the warranty. This warranty is not transferable. " +
            "No returns or exchanges will be accepted for wet products.";

        articledata_s[] articledata = {
            new articledata_s("Super Kite",  20),
            new articledata_s("Turbo Flyer", 40),
            new articledata_s("Giga Trash", 180),
            new articledata_s("Bare Bone Kit", 50),
            new articledata_s("Nitty Gritty", 20),
            new articledata_s("Pretty Dark Flyer", 75),
            new articledata_s("Large Hadron Glider", 85),
            new articledata_s("Flying Bat", 25),
            new articledata_s("Simple Dimple", 40),
            new articledata_s("Mega Sail", 95),
            new articledata_s("Tiny Tin", 25),
            new articledata_s("Monster Duck", 275),
            new articledata_s("Free Gift", 0),
        };
        int ARTICLECOUNT = articledata.Length;

        addressdata_s[] addressdata = {
            new addressdata_s("Edith", "Poulard", "Suite C", "Main Street", "New York"),
            new addressdata_s("Max", "Huber", "", "Lipton Avenue", "Albuquerque"),
            new addressdata_s("Herbert", "Pakard", "App. 29", "Easel", "Duckberg"),
            new addressdata_s("Charles", "Fever", "Office 3", "Scenic Drive", "Los Angeles"),
            new addressdata_s("D.", "Milliband", "", "Old Harbour", "Westland"),
            new addressdata_s("Lizzy", "Tin", "Workshop", "Ford", "Detroit" ),
            new addressdata_s("Patrick", "Black", "Backside", "Woolworth Street", "Clover"),
        };
        int ADDRESSCOUNT = addressdata.Length;

        string[] salesrepnames = {
            "Charles Ragner",
            "Hugo Baldwin",
            "Katie Blomock",
            "Ernie Bastel",
            "Lucy Irwin",
            "Bob Montagnier",
            "Chuck Hope",
            "Pierre Richard"
        };
        int SALESREPS = salesrepnames.Length;

        int[] salesrepimage = new int[SALESREPS];
        
        string[] headers = {
            "ITEM", "DESCRIPTION", "QUANTITY", "PRICE", "AMOUNT"
        };
        int COLUMNCOUNT = headers.Length;

        string[] alignments = {
            "right", "left", "right", "right", "right"
        };

        string[] months = { "January", "February", "March", "April", 
                            "May", "June", "July", "August", "September", 
                            "October", "November", "December" };

        int dpm = 0, cip4_root, cip4_metadata;

        /* create a new PDFlib object */
        p = new PDFlib();

        try
        {
            leading = fontsize + 2;

            if (p.begin_document("starter_pdfvt1.pdf",
                "pdfx=PDF/X-4 pdfvt=PDF/VT-1 usestransparency=false " +
                "nodenamelist={root recipient} recordlevel=1") == -1)
            {
                Console.WriteLine("Error: {0}", p.get_errmsg());
                return;
            }

            // This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return");

            // Set the search path for fonts and PDF files 
            p.set_option("SearchPath={{" + searchpath + "}}");

            p.set_info("Creator", "PDFlib starter sample");
            p.set_info("Title", "starter_pdfvt1");

            fontoptions = "fontname=" + fontname + " fontsize=" + fontsize
                            + " embedding encoding=unicode";

            /* Define output intent profile */
            if (p.load_iccprofile("ISOcoated_v2_eci.icc", "usage=outputintent") == -1)
            {
                Console.WriteLine("Error: {0}", p.get_errmsg());
                Console.WriteLine(
                        "See www.pdflib.com for output intent ICC profiles.");
                return;
            }

            /* -----------------------------------
             * Load company stationery as background (used on first page
             * for each recipient)
             * -----------------------------------
             */
            stationery = p.open_pdi_document(stationeryfilename, "");
            if (stationery == -1)
            {
                Console.WriteLine("Error: {0}", p.get_errmsg());
                return;
            }

            page = p.open_pdi_page(stationery, 1,
                    "pdfvt={scope=global environment={Kraxi Systems}}");
            if (page == -1)
            {
                Console.WriteLine("Error: {0}", p.get_errmsg());
                return;
            }

            /* -----------------------------------
             * Preload images of all local sales reps (used on first page
             * for each recipient). To get encapsulated image XObjects,
             * the renderingintent option is used.
             * -----------------------------------
             */
            for (i = 0; i < SALESREPS; i++)
            {
                buf = String.Format(salesrepfilename, i);

                int image = p.load_image("auto", buf,
                        "pdfvt={scope=file} renderingintent=Perceptual");
                if (image == -1)
                {
                    Console.WriteLine("Error: {0}", p.get_errmsg());
                    return;
                }
                salesrepimage[i] = image;
            }

            /* -----------------------------------
             * Construct DPM metadata for the DPart root node
             * -----------------------------------
             */
            cip4_metadata = p.poca_new("containertype=dict usage=dpm");
            p.poca_insert(cip4_metadata,
                    "type=string key=CIP4_Conformance value=base");
            p.poca_insert(cip4_metadata,
                    "type=string key=CIP4_Creator value=starter_pdfvt1");
            p.poca_insert(cip4_metadata,
                    "type=string key=CIP4_JobID value={Kraxi Systems invoice}");

            optlist = String.Format(
                "containertype=dict usage=dpm type=dict key=CIP4_Metadata "
                + "value={0}",
                cip4_metadata);
            cip4_root = p.poca_new(optlist);

            optlist = String.Format(
                "containertype=dict usage=dpm type=dict key=CIP4_Root "
                + "value={0}", cip4_root);
            dpm = p.poca_new(optlist);

            /* Create root node in the DPart hierarchy and add DPM metadata  */
            optlist = String.Format("dpm={0}", dpm);
            p.begin_dpart(optlist);

            p.poca_delete(dpm, "recursive=true");

            Random random = new Random();

            for (record = 0; record < MAXRECORD; record++)
            {
                byte[] datamatrix = new byte[MATRIXDATASIZE];
                int cip4_recipient, cip4_contact, cip4_person;
                string firstname, lastname, result;
                int pagecount=0;
                int item;
                
                firstname = addressdata[random.Next(ADDRESSCOUNT)].firstname;
                lastname = addressdata[random.Next(ADDRESSCOUNT)].lastname;

                /* -----------------------------------
                 * Construct DPM metadata for the next DPart node (i.e. the page)
                 * -----------------------------------
                 */
                dpm = p.poca_new("containertype=dict usage=dpm");
                cip4_root = p.poca_new("containertype=dict usage=dpm");
                cip4_recipient = p.poca_new("containertype=dict usage=dpm");
                cip4_contact = p.poca_new("containertype=dict usage=dpm");
                cip4_person = p.poca_new("containertype=dict usage=dpm");

                optlist = String.Format("type=dict key=CIP4_Root value={0}",
                                                cip4_root);
                p.poca_insert(dpm, optlist);

                optlist = String.Format(
                                "type=dict key=CIP4_Recipient value={0}",
                               cip4_recipient);
                p.poca_insert(cip4_root, optlist);

                optlist = String.Format(
                        "type=string key=CIP4_UniqueID value=ID_{0}", record);
                p.poca_insert(cip4_recipient, optlist);

                optlist = String.Format("type=dict key=CIP4_Contact value={0}",
                                                               cip4_contact);
                p.poca_insert(cip4_recipient, optlist);

                optlist = String.Format("type=dict key=CIP4_Person value={0}",
                                                               cip4_person);
                p.poca_insert(cip4_contact, optlist);

                optlist = String.Format(
                                "type=string key=CIP4_Firstname value={0}",
                                firstname);
                p.poca_insert(cip4_person, optlist);

                optlist = String.Format(
                                "type=string key=CIP4_Lastname value={0}",
                                lastname);
                p.poca_insert(cip4_person, optlist);

                /* Create a new node in the document part hierarchy and
                 * add DPM metadata
                 */
                optlist = String.Format("dpm={0}", dpm);
                p.begin_dpart(optlist);

                p.poca_delete(dpm, "recursive=true");

                /* -----------------------------------
                 * Create and place table with article list
                 * -----------------------------------
                 */
                /* ---------- Header row */
                int row = 1, col;
                int tbl = -1;

                for (col=1; col <= COLUMNCOUNT; col++)
                {
                    optlist = "fittextline={position={" + alignments[col-1]
                        + " center} " + fontoptions + "} margin=2";
                    tbl = p.add_table_cell(tbl, col, row, headers[col-1],
                                            optlist);
                }
                row++;

                /* ---------- Data rows: one for each article */
                double total = 0;

                /* -----------------------------------
                 * Print variable-length article list
                 * -----------------------------------
                 */
                for (i = 0, item = 0; i < ARTICLECOUNT; i++) {
                    int quantity = random.Next(9) + 1;
                    double sum;

                    if ((random.Next(2) % 2) != 0)
                        continue;

                    col = 1;

                    item++;
                    sum = articledata[i].price * quantity;

                    /* column 1: ITEM */
                    buf = "" + item;
                    optlist = "fittextline={position={" + alignments[col-1]
                            + " center} " + fontoptions
                            + "} colwidth=5% margin=2";
                    tbl = p.add_table_cell(tbl, col++, row, buf, optlist);

                    /* column 2: DESCRIPTION */
                    optlist = "fittextline={position={" + alignments[col-1]
                            + " center} " + fontoptions
                            + "} colwidth=50% margin=2";
                    tbl = p.add_table_cell(tbl, col++, row,
                            articledata[i].name, optlist);

                    /* column 3: QUANTITY */
                    buf = "" + quantity;
                    optlist = "fittextline={position={" + alignments[col-1]
                            + " center} " + fontoptions + "} margin=2";
                    tbl = p.add_table_cell(tbl, col++, row, buf, optlist);

                    /* column 4: PRICE */
                    buf = String.Format("{0:F2}", articledata[i].price);
                    optlist = String.Format(
                        "fittextline={{position={{{0} center}} {1}}} margin=2",
                        alignments[col-1], fontoptions);
                    tbl = p.add_table_cell(tbl, col++, row, buf, optlist);

                    /* column 5: AMOUNT */
                    buf = String.Format("{0:F2}", sum);
                    optlist = String.Format(
                        "fittextline={{position={{{0} center}} {1}}} margin=2",
                        alignments[col-1], fontoptions);
                    tbl = p.add_table_cell(tbl, col++, row, buf, optlist);

                    total += sum;
                    row++;
                }

                /* ---------- Print total in the rightmost column */
                buf = String.Format("{0:F2}", total);
                optlist = String.Format(
                        "fittextline={{position={{{0} center}} {1}}} margin=2",
                        alignments[COLUMNCOUNT-1], fontoptions);
                tbl = p.add_table_cell(tbl, COLUMNCOUNT, row++, buf, optlist);


                /* ---------- Footer row with terms of payment */
                optlist = fontoptions + " alignment=justify leading=120%";
                int tf = p.create_textflow(closingtext, optlist);

                optlist = "rowheight=1 margin=2 margintop=" + 2*fontsize
                        + " textflow=" + tf + " colspan=" + COLUMNCOUNT;
                tbl = p.add_table_cell(tbl, 1, row++, "", optlist);


                /* -- Place the table instance(s), creating pages as required */
                do {
                    double top;

                    p.begin_page_ext(0, 0,
                            "topdown=true width=a4.width height=a4.height");

                    if (++pagecount == 1)
                    {
                        /* -----------------------------------
                         * Place company stationery as background on first page
                         * for each recipient
                         * -----------------------------------
                         */
                        p.fit_pdi_page(page, 0, 842, "");

                        /* -----------------------------------
                         * Place name and image of local sales rep on first page
                         * for each recipient
                         * -----------------------------------
                         */
                        y = 177;
                        x = 455;

                        optlist = "fontname=" + fontname
                                + " encoding=winansi embedding fontsize=9";
                        p.fit_textline("Local sales rep:", x, y, optlist);
                        p.fit_textline(salesrepnames[record % SALESREPS],
                                x, y+9, optlist);

                        y = 280;
                        p.fit_image(salesrepimage[record % SALESREPS], x, y,
                                "boxsize={90 90} fitmethod=meet");


                        /* -----------------------------------
                         * Address of recipient
                         * -----------------------------------
                         */
                        y = 170;

                        optlist = "fontname=" + fontname
                                + " encoding=winansi embedding fontsize="
                                + fontsize;
                        buf = firstname + " " + lastname;
                        p.fit_textline(buf, left, y, optlist);

                        y += leading;
                        p.fit_textline(
                                addressdata[random.Next(ADDRESSCOUNT)].flat,
                                left, y, optlist);

                        y += leading;
                        buf = String.Format("{0} {1}", random.Next(999),
                                addressdata[random.Next(ADDRESSCOUNT)].street);
                        p.fit_textline(buf, left, y, optlist);

                        y += leading;
                        buf = String.Format("{0:D5} {1}", random.Next(99999),
                                addressdata[random.Next(ADDRESSCOUNT)].city);
                        p.fit_textline(buf, left, y, optlist);


                        /* -----------------------------------
                         * Individual barcode image for each recipient. To get
                         * encapsulated image XObjects the renderingintent
                         * option is used.
                         * -----------------------------------
                         */
                        create_datamatrix(datamatrix, record);
                        p.create_pvf("barcode", datamatrix, "");

                        barcodeimage = p.load_image("raw", "barcode",
                            "bpc=1 components=1 width=32 height=32 invert "
                            + "pdfvt={scope=singleuse} "
                            + "renderingintent=Saturation");
                        if (barcodeimage == -1) {
                            Console.WriteLine("Error: {0}", p.get_errmsg());
                            return;
                        }

                        p.fit_image(barcodeimage, 280.0, 200.0, "scale=1.5");
                        p.close_image(barcodeimage);
                        p.delete_pvf("barcode");


                        /* -----------------------------------
                         * Print header and date
                         * -----------------------------------
                         */
                        System.DateTime ltime = System.DateTime.Now;
                        y = 300;
                        buf = String.Format("INVOICE {0}-{1}", ltime.Year,
                                                record + 1);
                        optlist = "fontname=" + fontname
                                + " encoding=winansi embedding fontsize="
                                + fontsize;
                        p.fit_textline(buf, left, y, optlist);
                        
                        buf = String.Format("{0} {1}, {2}",
                                months[ltime.Month - 1], ltime.Day, ltime.Year);
                        optlist = String.Format(
                        "fontname={0} encoding=host fontsize={1} embedding " +
                        "position {{100 0}}", fontname, fontsize);
                        p.fit_textline(buf, right, y, optlist);

                        top = y + 2*leading;
                    }
                    else
                    {
                        top = 50;
                    }

                    /*
                     * Place the table on the page.
                     * Shade every other row, except the footer row.
                     */
                    result = p.fit_table(tbl,
                            left, bottom, right, top,
                            "header=1 "
                            + "fill={{area=rowodd fillcolor={gray 0.9}} "
                                + "{area=rowlast fillcolor={gray 1}}} "
                            + "rowheightdefault=auto colwidthdefault=auto");

                    if (result == "_error") {
                        Console.WriteLine("Couldn't place table: {0}",
                                                p.get_errmsg());
                        return;
                    }

                    p.end_page_ext("");
                } while (result == "_boxfull");

                p.delete_table(tbl, "");

                /* Close node in the document part hierarchy */
                p.end_dpart("");
            }

            p.close_pdi_page(page);
            p.close_pdi_document(stationery);

            for (i = 0; i < SALESREPS; i++)
            {
                p.close_image(salesrepimage[i]);
            }

            /* Close root node in the document part hierarchy */
            p.end_dpart("");

            p.end_document("");
        }
        catch (PDFlibException e)
        {
            // caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred:");
            Console.WriteLine("[{0}] {1}: {2}", e.get_errnum(),
                    e.get_apiname(), e.get_errmsg());
        }
        finally
        {
            if (p != null)
            {
                p.Dispose();
            }
        }
    }
    
    /* Simulate a datamatrix barcode
     */
    static void
    create_datamatrix(byte[] datamatrix, int record)
    {
        int i;

        for (i=0; i<MATRIXROWS; i++)
        {
            datamatrix[4 * i + 0] = (byte)((0xA3 + 1 * record + 17 * i) % 0xFF);
            datamatrix[4 * i + 1] = (byte)((0xA2 + 3 * record + 11 * i) % 0xFF);
            datamatrix[4 * i + 2] = (byte)((0xA0 + 5 * record + 7 * i) % 0xFF);
            datamatrix[4 * i + 3] = (byte)((0x71 + 7 * record + 9 * i) % 0xFF);
        }
        for (i=0; i<MATRIXROWS; i++)
        {
            datamatrix[4 * i + 0] |= 0x80;
            datamatrix[4 * i + 2] |= 0x80;
            if (i%2 != 0)
                datamatrix[4 * i + 3] |= 0x01;
            else
                datamatrix[4 * i + 3] &= 0xFE;
        }
        for (i=0; i<4; i++)
        {
            datamatrix[4 * (MATRIXROWS / 2 - 1) + i] = (byte)0xFF;
            datamatrix[4 * (MATRIXROWS - 1) + i] = (byte)0xFF;
        }
    }
    
}
