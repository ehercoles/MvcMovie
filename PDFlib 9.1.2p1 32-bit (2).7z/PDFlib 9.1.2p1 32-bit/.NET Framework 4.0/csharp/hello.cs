// $Id$
//
// PDFlib client: hello example in C#
//

using System;
using System.Text;
using PDFlib_dotnet;

class Hello {
    static void Main(string[] args) {

        PDFlib p;
        int font;

        p = new PDFlib();

        try 
        {
            // This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return");

            if (p.begin_document("hello.pdf", "") == -1) 
            {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            p.set_info("Creator", "hello.cs");
            p.set_info("Author", "Rainer Schaaf");
            p.set_info("Title", "Hello, world (.NET/C#)!");

            p.begin_page_ext(595, 842, "");

            font = p.load_font("Helvetica-Bold", "unicode", "");
            if (font == -1)
            {
                Console.WriteLine("Error: {0}\n", p.get_errmsg());
                return;
            }

            p.setfont(font, 24);
            p.set_text_pos(50, 700);
            p.show("Hello, world!");
            p.continue_text("(says .NET/C#)");
            p.end_page_ext("");

            p.end_document("");
        }

        catch (PDFlibException e)
        {
            // caught exception thrown by PDFlib
            Console.WriteLine("PDFlib exception occurred in hello sample:\n");
            Console.WriteLine("[{0}] {1}: {2}\n", e.get_errnum(),
                    e.get_apiname(), e.get_errmsg());
        } finally {
            if (p != null) {
                p.Dispose();
            }
        }
    }
}
