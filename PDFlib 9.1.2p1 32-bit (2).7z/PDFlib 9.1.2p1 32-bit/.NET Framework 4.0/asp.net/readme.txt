Refer to the PDFlib in .NET HowTo document for more details.


Using PDFlib with ASP.NET
=========================

To use the examples in the package with ASP.NET proceed as follows:

- copy the <installdir>\data directory (which contains the required
  input files for the samples) to the directory \inetpub\wwwroot
- copy the directory
  <installdir>\.NET Framework x.0\asp.net\ExamplesWebsite
  to the wwwroot directory
- copy the PDFlib assembly
  <installdir>\.NET Framework x.0\bin\pdflib_dotnet.dll to
  inetpub\wwwroot\ExamplesWebsite\Bin
- point your browser to the URLs of the examples and enjoy the generated PDFs,
  e.g. http://servername/ExamplesWebsite/
  If the Web page does not produce a PDF document, note any error messages
  or numbers in the generated HTML output.


Using PDFlib with .NET and Visual Studio
========================================

As an alternative to running the installed samples in ASP.NET you can
execute them in Visual Studio directly:

- copy the PDFlib assembly
  <installdir>\.NET Framework x.0\bin\pdflib_dotnet.dll to
  <installdir>\.NET Framework x.0\asp.net\ExamplesWebsite\Bin
  Keep in mind that Visual Studio is a 32-bit application and therefore
  requires the 32-bit edition of PDFlib.NET, even when running on a
  64-bit system.
- copy the <installdir>\data directory (which contains the required
  input files for the samples) to the directory
  <installdir>\.NET Framework x.0\asp.net\ExamplesWebsite\
- open <installdir>\.NET Framework x.0\asp.net\Examples.sln in
  Visual Studio, and click Debug, Start Without Debugging. In the summary
  HTML page which appears in the browser you can click on individual samples
  to create PDF output.
