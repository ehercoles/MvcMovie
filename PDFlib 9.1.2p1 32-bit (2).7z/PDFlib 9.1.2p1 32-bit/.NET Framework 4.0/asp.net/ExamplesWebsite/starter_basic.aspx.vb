' $Id$
'
' Basic starter:
' Create some simple text, vector graphics and image output
'
' required software: PDFlib/PDFlib+PDI/PPS 9
' required data: none
'
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_basic
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Dim p As PDFlib_dotnet.PDFlib = Nothing

        Const imagefile As String = "nesrin.jpg"
        Dim optlist As String
        Dim image As Integer
        Dim buf() As Byte

        Try
            p = New PDFlib()

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            ' Generate a PDF in memory
            If p.begin_document("", "") = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_basic")

            ' We load the image before the first page, and use it
            ' on all pages
            image = p.load_image("auto", imagefile, "")

            If image = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            ' Page 1
            p.begin_page_ext(595, 842, "")

            ' use LinLibertine_R font and unicode encoding for placing the text
            ' and demonstrate various options how to pass the unicode text to PDFlib

            optlist = "fontname={LinLibertine_R} encoding=unicode embedding fontsize=24 "

            ' using plain 7 bit ASCII text
            p.fit_textline("en: Hello!", 50, 700, optlist)
            ' using unicode escapes
            p.fit_textline("gr: " & ChrW(&H393) & ChrW(&H3B5) & ChrW(&H3B9) & ChrW(&H3AC) & "!", 50, 650, optlist)
            p.fit_textline("ru: " & ChrW(&H41F) & ChrW(&H440) & ChrW(&H438) & ChrW(&H432) & ChrW(&H435) & ChrW(&H442) & "!", 50, 600, optlist)
            ' using PDFlib's character references
            p.fit_textline("es: &#xA1;Hola!", 50, 550, optlist + " charref=true")

            p.fit_image(image, 0.0, 0.0, "scale=0.25")

            p.end_page_ext("")

            ' Page 2
            p.begin_page_ext(595, 842, "")

            ' red rectangle
            p.setcolor("fill", "rgb", 1.0, 0.0, 0.0, 0.0)
            p.rect(200, 200, 250, 150)
            p.fill()

            ' blue circle
            p.setcolor("fill", "rgb", 0.0, 0.0, 1.0, 0.0)
            p.arc(400, 600, 100, 0, 360)
            p.fill()

            ' thick gray line
            p.setcolor("stroke", "gray", 0.5, 0.0, 0.0, 0.0)
            p.setlinewidth(10)
            p.moveto(100, 500)
            p.lineto(300, 700)
            p.stroke()

            ' Using the same image handle means the data will be copied
            ' to the PDF only once, which saves space.
            p.fit_image(image, 150.0, 25.0, "scale=0.25")
            p.end_page_ext("")

            ' Page 3
            p.begin_page_ext(595, 842, "")

            ' Fit the image to a box of predefined size (without distortion)
            optlist = "boxsize={400 400} position={center} fitmethod=meet"

            p.fit_image(image, 100, 200, optlist)

            p.end_page_ext("")

            p.close_image(image)
            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=starter_basic.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
