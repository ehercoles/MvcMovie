' $Id$
' Starter sample for fallback fonts
'
' Required software: PDFlib/PDFlib+PDI/PPS 9
' Required data: suitable fonts, Japanese CMaps
'

Imports System
Imports System.Text
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_fallback
    Inherits System.Web.UI.Page


    Structure testcase
        Public usecase As String
        Public fontname As String
        Public encoding As String
        Public fallbackoptions As String
        Public text As String
        ' Constructor
        Public Sub New(ByVal s_usecase As String, ByVal s_fontname As String, _
             ByVal s_encoding As String, ByVal s_fallbackoptions As String, _
             ByVal s_text As String)
            usecase = s_usecase
            fontname = s_fontname
            encoding = s_encoding
            fallbackoptions = s_fallbackoptions
            text = s_text
        End Sub
    End Structure

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Dim outfile As String = ""
        Dim buf() As Byte

        Dim p As PDFlib_dotnet.PDFlib = Nothing

        Dim optlist As New StringBuilder()
        Dim row, col, table, test As Integer
        Dim llx As Double = 50
        Dim lly As Double = 50
        Dim urx As Double = 800
        Dim ury As Double = 550
        Dim result As String

        Dim header() As String = { _
            "Use case", _
            "Option list for the 'fallbackfonts' option", _
            "Base font", _
            "With fallback font" _
        }
        Dim MAXCOL As Integer = header.Length

        Dim testcases() As testcase = { _
          New testcase("Extend 8-bit encoding", _
          "Helvetica", _
          "iso8859-1", _
          "{fontname=Helvetica encoding=unicode forcechars=euro}", _
           "123&euro;"), _
          New testcase("Use Euro glyph from another font", _
          "Courier", _
          "winansi", _
          "{fontname=Helvetica encoding=unicode forcechars=euro textrise=-5%}", _
           "123&euro;"), _
          New testcase("Enlarge all glyphs in a font", _
          "Times-Italic", _
          "winansi", _
          "{fontname=Times-Italic encoding=unicode forcechars={U+0020-U+00FF} " & _
          "fontsize=120%}", _
           "font size"), _
          New testcase("Add enlarged pictogram", _
          "Times-Roman", _
          "unicode", _
          "{fontname=ZapfDingbats encoding=unicode forcechars=.a12 " & _
          "fontsize=150% textrise=-15%}", _
          "Bullet symbol: &.a12;"), _
          New testcase("Add enlarged symbol glyph", _
          "Times-Roman", _
          "unicode", _
          "{fontname=Symbol encoding=unicode forcechars=U+2663 fontsize=125%}", _
           "Club symbol: &#x2663;"), _
          New testcase("Add Greek characters to Latin font", _
          "Times-Roman", _
          "unicode", _
          "{fontname=Symbol encoding=unicode}", _
           "Greek text: &#x039B;&#x039F;&#x0393;&#x039F;&#x03A3;"), _
          New testcase("Gaiji with EUDC font", _
          "KozMinProVI-Regular", _
          "unicode", _
          "{fontname=EUDC encoding=unicode forcechars=U+E000 fontsize=140% " & _
          "textrise=-20%}", _
           "Gaiji: &#xE000;"), _
          New testcase("Gaiji with SING font", _
          "KozMinProVI-Regular", _
          "unicode", _
          "{fontname=PDFlibWing encoding=unicode forcechars=gaiji}", _
           "Gaiji: &#xE000;"), _
          New testcase("Replace Latin characters in CJK font", _
          "KozMinProVI-Regular", _
          "unicode", _
          "{fontname=Courier-Bold encoding=unicode forcechars={U+0020-U+007E}}", _
           "Latin and &#x65E5;&#x672C;&#x8A9E;"), _
          New testcase("Identify missing glyphs", _
          "Times-Roman", _
          "unicode", _
          "{fontname=fallback encoding=unicode}", _
           "Missing glyphs: &#x1234; &#x672C; &#x8A9E;") _
 }
        Dim n_testcases As Integer = testcases.Length

        ' create a new PDFlib object
        p = New PDFlib()

        Try
            ' This means that formatting and other errors will raise an
            ' exception. This simplifies our sample code, but is not
            ' recommended for production code.
            '/
            p.set_option("errorpolicy=exception")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}} charref=true glyphcheck=replace")

            ' Set an output path according to the name of the topic
            If (p.begin_document(outfile, "") = -1) Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_fallback")

            ' Start Page
            p.begin_page_ext(0, 0, "width=a4.height height=a4.width")

            table = -1

            ' Table header
            row = 1
            For col = 1 To MAXCOL Step 1
                optlist.Length = 0
                optlist.Append("fittextline={fontname=Helvetica-Bold " & _
                    "encoding=unicode fontsize=11} margin=4")
                table = p.add_table_cell(table, col, row, header(col - 1), _
                 optlist.ToString())
            Next

            ' Create fallback samples, one use case per row
            row = 2
            For test = 0 To n_testcases - 1 Step 1
                col = 1

                ' Column 1: description of the use case
                optlist.Length = 0
                optlist.Append("fittextline={fontname=Helvetica " & _
                 "encoding=unicode fontsize=11} margin=4")
                table = p.add_table_cell(table, col, row, _
             testcases(test).usecase, optlist.ToString())
                col = col + 1

                ' Column 2: reproduce option list literally
                optlist.Length = 0
                optlist.Append("fittextline={fontname=Helvetica " & _
                 "encoding=unicode fontsize=10} margin=4")
                table = p.add_table_cell(table, col, row, _
                    testcases(test).fallbackoptions, optlist.ToString())
                col = col + 1

                ' Column 3: text with base font
                optlist.Length = 0
                optlist.Append("fittextline={fontname=")
                optlist.AppendFormat("{0}", testcases(test).fontname)
                optlist.Append(" encoding=")
                optlist.AppendFormat("{0}", testcases(test).encoding)
                optlist.Append(" fontsize=11 replacementchar=? } margin=4")
                table = p.add_table_cell(table, col, row, _
                 testcases(test).text, optlist.ToString())
                col = col + 1

                ' Column 4: text with base font and fallback fonts
                optlist.Length = 0
                optlist.Append("fittextline={fontname=")
                optlist.AppendFormat("{0}", testcases(test).fontname)
                optlist.Append(" encoding=")
                optlist.AppendFormat("{0}", testcases(test).encoding)
                optlist.Append(" fontsize=11 fallbackfonts={")
                optlist.AppendFormat("{0}", testcases(test).fallbackoptions)
                optlist.Append("}} margin=4")
                table = p.add_table_cell(table, col, row, _
                   testcases(test).text, optlist.ToString())
                col = col + 1
                row = row + 1
            Next

            ' Place the table
            optlist.Length = 0
            optlist.Append("header=1 fill={{area=rowodd " & _
         "fillcolor={gray 0.9}}} stroke={{line=other}} ")
            result = p.fit_table(table, llx, lly, urx, ury, optlist.ToString())

            If (result = "_error") Then
                Throw New System.Exception("Couldn't place table: " & p.get_errmsg())
            End If

            p.end_page_ext("")
            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=starter_fallback.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)


        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
