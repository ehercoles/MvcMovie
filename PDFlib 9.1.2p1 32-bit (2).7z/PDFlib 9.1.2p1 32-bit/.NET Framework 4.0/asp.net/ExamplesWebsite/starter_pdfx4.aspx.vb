' $Id$
'
' PDF/X-4 starter:
' Create PDF/X-4 conforming output with layers and transparency
'
' A low-level layer is created for each of several languages, as well
' as an image layer. 
'
' The document contains transparent text which is allowed in
' PDF/X-4, but not earlier PDF/X standards.
'
' Required software: PDFlib/PDFlib+PDI/PPS 9
' Required data: font file, image file, ICC output intent profile
'                (see www.pdflib.com for output intent ICC profiles)
'

Imports System
Imports System.Text
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_pdfx4
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Const imagefile As String = "zebra.tif"

        Dim p As PDFlib_dotnet.PDFlib = Nothing

        Dim optlist As New StringBuilder
        Dim buf() As Byte

        Dim font, image, icc, gstate As Integer
        Dim layer_english, layer_german, layer_french, layer_image As Integer
        Dim width, height As Double

        ' create a new PDFlib object
        p = New PDFlib()

        Try
            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            If (p.begin_document("", "pdfx=PDF/X-4") = -1) Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_pdfx4")


            If (p.load_iccprofile("ISOcoated_v2_eci.icc", "usage=outputintent") = -1) Then
                Throw New System.Exception("Error: " & p.get_errmsg() & _
                    "See www.pdflib.com for output intent ICC profiles.")
            End If

            ' Define the layers; "defaultstate" specifies whether or not
            ' the layer is visible when the page is opened.
            '/

            layer_english = p.define_layer("English text", "defaultstate=true")
            layer_german = p.define_layer("German text", "defaultstate=false")
            layer_french = p.define_layer("French text", "defaultstate=false")

	    ' Define a radio button relationship for the language layers.
	    '/
            optlist.Length = 0
            optlist.AppendFormat("group={{ {0} {1} {2} }}", _
                    layer_english, layer_german, layer_french)
            p.set_layer_dependency("Radiobtn", optlist.ToString())

            layer_image = p.define_layer("Images", "defaultstate=true")

            p.begin_page_ext(595, 842, "")

            ' Font embedding is required for PDF/X
            font = p.load_font("LuciduxSans-Oblique", "winansi", "embedding")

            If (font = -1) Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.setfont(font, 24)

            p.begin_layer(layer_english)

            p.fit_textline("PDF/X-4 starter sample with layers", 50, 700, "")

            p.begin_layer(layer_german)
            p.fit_textline("PDF/X-4 Starter-Beispiel mit Ebenen", 50, 700, "")

            p.begin_layer(layer_french)
            p.fit_textline("PDF/X-4 Starter exemple avec des calques", 50, 700, "")

            p.begin_layer(layer_image)

            p.setfont(font, 48)

            ' The RGB image needs an ICC profile; we use sRGB.
            icc = p.load_iccprofile("sRGB", "")
            if (icc = -1) Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            optlist.Length = 0
            optlist.AppendFormat("iccprofile={0}", icc)
            image = p.load_image("auto", imagefile, optlist.ToString())

            If (image = -1) Then
                Return
            End If

            ' Place a diagonal stamp across the image area
            width = p.info_image(image, "width", "")
            height = p.info_image(image, "height", "")

            optlist.Length = 0
            optlist.Append("boxsize={")
            optlist.AppendFormat("{0} {1}", width, height)
            optlist.Append("} stamp=ll2ur")
            p.fit_textline("Zebra", 0, 0, optlist.ToString())

            ' Set transparency in the graphics state
            gstate = p.create_gstate("opacityfill=0.5")
            p.set_gstate(gstate)

            ' Place the image on the page and close it
            p.fit_image(image, 0.0, 0.0, "")
            p.close_image(image)

            ' Close all layers
            p.end_layer()

            p.end_page_ext("")
            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=starter_pdfx4.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)


        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
