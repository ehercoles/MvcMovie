' $Id$
'
' PDF/X-3 starter:
' Create PDF/X-3 conforming output
'
' Required software: PDFlib/PDFlib+PDI/PPS 9
' Required data: font file, image file, ICC profile
'                (see www.pdflib.com for output intent ICC profiles)
'
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_pdfx3
    Inherits System.Web.UI.Page
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Const imagefile As String = "nesrin.jpg"

        Dim p As PDFlib_dotnet.PDFlib = Nothing


        Dim font, image, spot, icc As Integer
        Dim buf() As Byte

        Try
            p = New PDFlib()

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            ' Generate a PDF in memory.
            If p.begin_document("", "pdfx=PDF/X-3:2003") = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_pdfx3")

            '
            ' You can use one of the Standard output intents (e.g. for SWOP
            ' printing) which do not require an ICC profile:
            '
            ' p.load_iccprofile("CGATS TR 001", "usage=outputintent")
            '
            ' However, if you use ICC or Lab color you must load an ICC
            ' profile as output intent:
            If p.load_iccprofile("ISOcoated_v2_eci.icc", "usage=outputintent") = -1 Then
                Throw New System.Exception( _
                    "Error: " & p.get_errmsg() & "<br>" & _
                    "See www.pdflib.com for output intent ICC profiles.")
            End If

            p.begin_page_ext(595, 842, "")

            ' Font embedding is required for PDF/X
            font = p.load_font("LuciduxSans-Oblique", "unicode", "embedding")

            If font = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.setfont(font, 24)

            spot = p.makespotcolor("PANTONE 123 C")
            p.setcolor("fill", "spot", spot, 1.0, 0.0, 0.0)
            p.fit_textline("PDF/X-3:2003 starter", 50, 700, "")

            ' The RGB image below needs an ICC profile; we use sRGB.
            icc = p.load_iccprofile("sRGB", "")

            If icc = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If
            image = p.load_image("auto", imagefile, "iccprofile=" & icc)

            If image = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.fit_image(image, 0.0, 0.0, "scale=0.5")

            p.end_page_ext("")

            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=starter_pdfx3.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
