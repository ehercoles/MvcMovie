' $Id$
'
' Basic utility functions for PDFlib ASP.NET starter examples
'
Imports System.Web

Public Class StarterUtils
    Shared Sub WriteErrorPage(ByVal Response As HttpResponse, ByVal s As String)
        WritePageHeader(Response, "PDFlib Error")
        ResponseWriteLn(Response, "<body>")
        Response.Write(s)
        ResponseWriteLn(Response, "</body>")
        ResponseWriteLn(Response, "</html>")
    End Sub

    Shared Sub WritePageHeader(ByVal Response As HttpResponse, ByVal title As String)
        ResponseWriteLn(Response, "<html>")
        ResponseWriteLn(Response, "<head>")
        ResponseWriteLn(Response, "<title>" & title & "</title>")
        ResponseWriteLn(Response, "<style type=""text/css"">")
        ResponseWriteLn(Response, ".section { padding:5px; border:thin solid; border-color:#FB7115; margin:10px; }")
        ResponseWriteLn(Response, ".section-title { font-weight:bold; }")
        ResponseWriteLn(Response, "</style>")
        ResponseWriteLn(Response, "</head>")
    End Sub

    Shared Sub ResponseWriteLn(ByVal Response As HttpResponse, ByVal s As String)
        Response.Write(s & vbLf)
    End Sub

End Class
