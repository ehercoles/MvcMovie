' $Id$
'
' Textflow starter:
' Create multi-column text output which may span multiple pages
'
' required software: PDFlib/PDFlib+PDI/PPS 9
' required data: none
'
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_textflow
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim p As PDFlib_dotnet.PDFlib = Nothing

        Dim i As Integer, tf As Integer = -1
        Dim result As String
        Const llx1 As Double = 50, lly1 As Double = 50
        Const urx1 As Double = 250, ury1 As Double = 800
        Const llx2 As Double = 300, lly2 As Double = 50
        Const urx2 As Double = 500, ury2 As Double = 800

        ' Repeat the dummy text to produce more contents
        Const count As Integer = 50

        Const optlist1 As String = _
            "fontname=Helvetica fontsize=10.5 encoding=unicode " & _
            "fillcolor={gray 0} alignment=justify"

        Const optlist2 As String = _
            "fontname=Helvetica-Bold fontsize=14 encoding=unicode " & _
            "fillcolor={rgb 1 0 0} charref"

        ' Dummy text for filling the columns. Soft hyphens are marked with
        ' the character reference "&shy;" (character references are
        ' enabled by the charref option).

        Const text As String = _
            "Lorem ipsum dolor sit amet, consectetur adi&shy;pi&shy;sicing elit, sed do eius&shy;mod tempor incidi&shy;dunt ut labore et dolore magna ali&shy;qua. Ut enim ad minim ve&shy;niam, quis nostrud exer&shy;citation ull&shy;amco la&shy;bo&shy;ris nisi ut ali&shy;quip ex ea commodo con&shy;sequat. Duis aute irure dolor in repre&shy;henderit in voluptate velit esse cillum dolore eu fugiat nulla pari&shy;atur. Excep&shy;teur sint occae&shy;cat cupi&shy;datat non proident, sunt in culpa qui officia dese&shy;runt mollit anim id est laborum. "
        Dim buf() As Byte

        Try
            p = New PDFlib()

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

            ' Generate a PDF in memory.
            If p.begin_document("", "") = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_textflow")

            ' Create some amount of dummy text and feed it to a Textflow
            ' object with alternating options. 

            For i = 1 To count
                Dim num As String = i & " "

                tf = p.add_textflow(tf, num, optlist2)
                If tf = -1 Then
                    Throw New System.Exception("Error: " & p.get_errmsg())
                End If

                tf = p.add_textflow(tf, text, optlist1)
                If tf = -1 Then
                    Throw New System.Exception("Error: " & p.get_errmsg())
                End If
            Next i

            ' Loop until all of the text is placed; create new pages
            ' as long as more text needs to be placed. Two columns will
            ' be created on all pages.

            Do
                ' Add "showborder" to visualize the fitbox borders
                Dim optlist As String = _
                    "verticalalign=justify linespreadlimit=120% "

                p.begin_page_ext(0, 0, "width=a4.width height=a4.height")

                ' Fill the first column
                result = p.fit_textflow(tf, llx1, lly1, urx1, ury1, optlist)

                ' Fill the second column if we have more text
                If result <> "_stop" Then
                    result = p.fit_textflow(tf, llx2, lly2, urx2, ury2, optlist)
                End If

                p.end_page_ext("")

                ' "_boxfull" means we must continue because there is more text
                ' "_nextpage" is interpreted as "start new column"
            Loop While result = "_boxfull" Or result = "_nextpage"

            ' Check for errors
            If result <> "_stop" Then
                ' "_boxempty" happens if the box is very small and doesn't
                ' hold any text at all.

                If result <> "_boxempty" Then
                    Throw New System.Exception("Error: Textflow box too small")
                Else
                    ' Any other return value is a user exit caused by
                    ' the "return" option; this requires dedicated code to
                    ' deal with.
                    Throw New System.Exception("User return '" & result & _
                      "' found in Textflow")
                End If
            End If

            p.delete_textflow(tf)

            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=starter_textflow.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
