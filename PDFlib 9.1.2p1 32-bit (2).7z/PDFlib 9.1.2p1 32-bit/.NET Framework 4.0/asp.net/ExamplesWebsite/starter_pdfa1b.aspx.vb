' $Id$
'
' PDF/A-1b starter:
' Create PDF/A-1b conforming output
'
' Required software: PDFlib/PDFlib+PDI/PPS 9
' Required data: font file, image file
'
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_pdfa1b
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Const imagefile As String = "nesrin.jpg"

        Dim p As PDFlib_dotnet.PDFlib = Nothing


        Dim font, image As Integer
        Dim buf() As Byte

        Try
            p = New PDFlib()

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            ' Generate a PDF in memory.
            ' PDF/A-1a requires Tagged PDF
            If p.begin_document("", "pdfa=PDF/A-1b:2005") = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            ' We use sRGB as output intent since it allows the color
            ' spaces CIELab, ICC-based, grayscale, and RGB.
            '
            ' If you need CMYK color you must use a CMYK output profile.

            if p.load_iccprofile("sRGB", "usage=outputintent") = -1 Then
                Throw New Exception("Error: " + p.get_errmsg() + 
                    "\nSee www.pdflib.com for output intent ICC profiles")
            End if

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_pdfa1b")

            p.begin_page_ext(595, 842, "")

            ' Font embedding is required for PDF/A
            font = p.load_font("LuciduxSans-Oblique", "unicode", "embedding")

            If font = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.setfont(font, 24)

            p.fit_textline("PDF/A-1b:2005 starter", 50, 700, "")

            ' We can use an RGB image since we already supplied an
            ' output intent profile.

            image = p.load_image("auto", imagefile, "")

            If image = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            ' Place the image at the bottom of the page
            p.fit_image(image, 0.0, 0.0, "scale=0.5")

            p.end_page_ext("")
	    p.close_image(image)

            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=starter_pdfa1b.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
