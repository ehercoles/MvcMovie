' $Id$
'
' PDFlib client: block processing in ASP.NET
'

Imports PDFlib_dotnet
Imports StarterUtils

Partial Class businesscard
    Inherits System.Web.UI.Page

    Dim p As PDFlib_dotnet.PDFlib = Nothing

    Structure blockdata
        Public name, value As String

        ' Constructor:
        Public Sub New(ByVal s_name As String, ByVal s_value As String)
            name = s_name
            value = s_value
        End Sub

    End Structure

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' This is where font/image/PDF input files live. Adjust as necessary.
        '
        ' Note that this directory must also contain the LuciduxSans font
        ' outline and metrics files.
        '
        Dim searchpath As String = Server.MapPath("data")

        Const infile As String = "boilerplate.pdf"

        Dim i, blockcontainer, page As Integer
        Dim buf() As Byte

        Dim data(7) As blockdata
        Dim BLOCKCOUNT As Integer

        data(0) = New blockdata("name", "Victor Kraxi")
        data(1) = New blockdata("business.title", "Chief Paper Officer")
        data(2) = New blockdata("business.address.line1", "17, Aviation Road")
        data(3) = New blockdata("business.address.city", "Paperfield")
        data(4) = New blockdata("business.telephone.voice", "phone +1 234 567-89")
        data(5) = New blockdata("business.telephone.fax", "fax +1 234 567-89")
        data(6) = New blockdata("business.email", "victor@kraxi.com")
        data(7) = New blockdata("business.homepage", "www.kraxi.com")

        BLOCKCOUNT = data.Length


        Try
            p = New PDFlib()

            p.begin_document("", "")

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            p.set_info("Creator", "businesscard.vb.aspx")
            p.set_info("Author", "Rainer Schaaf")
            p.set_info("Title", "PDFlib block processing sample (ASP.NET/VB)")

            blockcontainer = p.open_pdi_document(infile, "")
            If (blockcontainer = -1) Then
                Response.Write("Error: " & p.get_errmsg())
                Return
            End If

            page = p.open_pdi_page(blockcontainer, 1, "")

            If (page = -1) Then
                Response.Write("Error: " & p.get_errmsg())
                Return
            End If

            p.begin_page_ext(20, 20, "")   ' dummy page size

            ' This will adjust the page size to the block container's size
            p.fit_pdi_page(page, 0, 0, "adjustpage")

            For i = 0 To (BLOCKCOUNT - 1) Step 1
                If (p.fill_textblock(page, data(i).name, data(i).value, "embedding pdiwarning encoding=unicode") = -1) Then
                    Response.Write("Warning: " & p.get_errmsg())
                End If
            Next

            p.end_page_ext("")
            p.close_pdi_page(page)

            p.end_document("")
            p.close_pdi_document(blockcontainer)

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=businesscard.vb.aspx.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)
            Response.End()

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
