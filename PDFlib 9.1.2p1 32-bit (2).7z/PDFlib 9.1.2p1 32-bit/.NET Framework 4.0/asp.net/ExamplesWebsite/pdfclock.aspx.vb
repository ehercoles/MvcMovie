    ' $Id$
    '
    ' PDFlib client: pdfclock example for ASP.NET
    '

Imports PDFlib_dotnet
Imports StarterUtils

Partial Class pdfclock
    Inherits System.Web.UI.Page

    Dim p As PDFlib_dotnet.PDFlib = Nothing

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim buf() As Byte

        Dim ltime As System.DateTime
        Dim RADIUS As Double
        Dim MARGIN As Double
        Dim alpha As Double

        RADIUS = 200.0
        MARGIN = 20.0

        Try
            p = New PDFlib()

            ' This means we must check return values of load_font() etc.
            p.set_option("errorpolicy=return")

            p.begin_document("", "")

            p.set_info("Creator", "pdfclock.vb.aspx")
            p.set_info("Author", "Rainer Schaaf")
            p.set_info("Title", "PDF clock (ASP.NET/VB)")

            p.begin_page_ext((2 * (RADIUS + MARGIN)), (2 * (RADIUS + MARGIN)), "")

            p.translate(RADIUS + MARGIN, RADIUS + MARGIN)
            p.setcolor("fillstroke", "rgb", 0.0, 0.0, 1.0, 0.0)
            p.save()

            ' minute strokes
            p.setlinewidth(2.0)

            For alpha = 0 To 359 Step 6
                p.rotate(6.0)
                p.moveto(RADIUS, 0.0)
                p.lineto((RADIUS - MARGIN / 3), 0.0)
                p.stroke()
            Next alpha

            p.restore()
            p.save()

            ' 5 minute strokes
            p.setlinewidth(3.0)
            For alpha = 0 To 359 Step 30
                p.rotate(30.0)
                p.moveto(RADIUS, 0.0)
                p.lineto(RADIUS - MARGIN, 0.0)
                p.stroke()
            Next alpha

            ltime = System.DateTime.Now

            ' draw hour hand
            p.save()
            p.rotate((-((ltime.Minute / 60.0F) + ltime.Hour - 3.0F) * 30.0F))
            p.moveto(-RADIUS / 10, -RADIUS / 20)
            p.lineto(RADIUS / 2, 0.0F)
            p.lineto(-RADIUS / 10, RADIUS / 20)
            p.closepath()
            p.fill()
            p.restore()

            ' draw minute hand
            p.save()
            p.rotate((-((ltime.Second / 60.0F) + ltime.Minute - 15.0F) * 6.0F))
            p.moveto(-RADIUS / 10, -RADIUS / 20)
            p.lineto(RADIUS * 0.8F, 0.0F)
            p.lineto(-RADIUS / 10, RADIUS / 20)
            p.closepath()
            p.fill()
            p.restore()

            ' draw second hand
            p.setcolor("fillstroke", "rgb", 1.0, 0.0, 0.0, 0.0)
            p.setlinewidth(2)
            p.save()
            p.rotate(-((ltime.Second - 15.0F) * 6.0))
            p.moveto(-RADIUS / 5, 0.0F)
            p.lineto(RADIUS, 0.0F)
            p.stroke()
            p.restore()

            ' draw little circle at center
            p.circle(0, 0, RADIUS / 30)
            p.fill()

            p.restore()

            p.end_page_ext("")
            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=pdfclock.vb.aspx.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)
            Response.End()

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
