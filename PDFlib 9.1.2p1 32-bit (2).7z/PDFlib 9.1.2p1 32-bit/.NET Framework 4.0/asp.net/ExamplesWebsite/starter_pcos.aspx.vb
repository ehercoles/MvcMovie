' $Id$
'
' pCOS starter:
' Dump information from an existing PDF document
'
' required software: PDFlib+PDI/PPS 9
' required data: PDF input file
'
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_pcos
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Dim pdfinput As String = Server.MapPath("data/TET-datasheet.pdf")
        Const docoptlist As String = "requiredmode=minimum"

        Dim p As PDFlib_dotnet.PDFlib = Nothing

        Dim count, pcosmode As Integer
        Dim i, doc As Integer
        Dim objtype As String
        Dim xfa_present, plainmetadata As Boolean

        Try
            p = New PDFlib()

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            ' We do not create any output document, so no call to
            ' begin_document() is required.


            ' Open the input document
            doc = p.open_pdi_document(pdfinput, docoptlist)
            If doc = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            WritePageHeader(Response, "PDFlib pCOS Starter Example")
            ResponseWriteLn(Response, "<body>")

            ' --------- general information (always available)
            ResponseWriteLn(Response, "<div class=""section"">")
            ResponseWriteLn(Response, "<span class=""section-title"">General Information</span>")
            pcosmode = p.pcos_get_number(doc, "pcosmode")

            ResponseWriteLn(Response, "<p>File name: " & _
                        p.pcos_get_string(doc, "filename") & "<br>")

            ResponseWriteLn(Response, "PDF version: " & _
                        p.pcos_get_string(doc, "pdfversionstring") & "<br>")

            ResponseWriteLn(Response, "Encryption: " & _
                        p.pcos_get_string(doc, "encrypt/description") & "<br>")

            If p.pcos_get_number(doc, "encrypt/master") <> 0 Then
                ResponseWriteLn(Response, "Master pw: yes<br>")
            Else
                ResponseWriteLn(Response, "Master pw: no<br>")
            End If

            If p.pcos_get_number(doc, "encrypt/user") <> 0 Then
                ResponseWriteLn(Response, "User pw: yes<br>")
            Else
                ResponseWriteLn(Response, "User pw: no<br>")
            End If

            If p.pcos_get_number(doc, "encrypt/nocopy") <> 0 Then
                ResponseWriteLn(Response, "Text copying: no<br>")
            Else
                ResponseWriteLn(Response, "Text copying: yes<br>")
            End If

            If p.pcos_get_number(doc, "linearized") <> 0 Then
                ResponseWriteLn(Response, "Linearized: yes<br>")
            Else
                ResponseWriteLn(Response, "Linearized: no<br>")
            End If

            ResponseWriteLn(Response, "</div>")

            If pcosmode = 0 Then
                ResponseWriteLn(Response, "<div class=""section"">")
                ResponseWriteLn(Response, "<span class=""section-title"">Minimum mode: no more information available</span>")
                ResponseWriteLn(Response, "</div>")
                Exit Try
            End If

            ' --------- more details (requires at least user password)
            ResponseWriteLn(Response, "<div class=""section"">")
            ResponseWriteLn(Response, "<span class=""section-title"">More Details</span>")

            ResponseWriteLn(Response, "<p>PDF/X status: " & p.pcos_get_string(doc, "pdfx") & "<br>")

            ResponseWriteLn(Response, "PDF/A status: " & p.pcos_get_string(doc, "pdfa") & "<br>")

            xfa_present = p.pcos_get_string(doc, "type:/Root/AcroForm/XFA") <> "null"
            If xfa_present Then
                ResponseWriteLn(Response, "XFA data: yes<br>")
            Else
                ResponseWriteLn(Response, "XFA data: no<br>")
            End If

            If p.pcos_get_number(doc, "tagged") <> 0 Then
                ResponseWriteLn(Response, "Tagged PDF: yes<br>")
            Else
                ResponseWriteLn(Response, "Tagged PDF: no<br>")
            End If

            ResponseWriteLn(Response, "No. of pages: " & _
                        p.pcos_get_number(doc, "length:pages") & "<br>")

            ResponseWriteLn(Response, String.Format("Page 1 size: width={0:0.000}, height={1:0.000}<br>", _
             p.pcos_get_number(doc, "pages[0]/width"), _
             p.pcos_get_number(doc, "pages[0]/height")))

            count = p.pcos_get_number(doc, "length:fonts")
            ResponseWriteLn(Response, "No. of fonts: " & count & "<br>")

            For i = 0 To count - 1
                Dim fonts As String = "fonts[" & i & "]/embedded"

                If p.pcos_get_number(doc, fonts) <> 0 Then
                    ResponseWriteLn(Response, "embedded ")
                Else
                    ResponseWriteLn(Response, "unembedded ")
                End If

                fonts = "fonts[" & i & "]/type"
                ResponseWriteLn(Response, p.pcos_get_string(doc, fonts) & " font ")
                fonts = "fonts[" & i & "]/name"
                ResponseWriteLn(Response, p.pcos_get_string(doc, fonts) & "<br>")
            Next i

            ResponseWriteLn(Response, "</div>")

            plainmetadata = p.pcos_get_number(doc, "encrypt/plainmetadata") <> 0

            If pcosmode = 1 And Not plainmetadata _
                    And p.pcos_get_number(doc, "encrypt/nocopy") <> 0 Then
                ResponseWriteLn(Response, "<div class=""section"">")
                ResponseWriteLn(Response, "<span class=""section-title"">Restricted mode: no more information available</span>")
                ResponseWriteLn(Response, "</div>")
                Exit Try
            End If

            ' ----- document info keys and XMP metadata (requires master pw)
            ResponseWriteLn(Response, "<div class=""section"">")
            ResponseWriteLn(Response, "<span class=""section-title"">Document Info Keys</span>")

            count = p.pcos_get_number(doc, "length:/Info")

            ResponseWriteLn(Response, "<p>")
            For i = 0 To count - 1
                Dim info As String
                Dim key As String

                info = "type:/Info[" & i & "]"
                objtype = p.pcos_get_string(doc, info)

                info = "/Info[" & i & "].key"
                key = p.pcos_get_string(doc, info)

                ResponseWriteLn(Response, key & ": ")

                ' Info entries can be stored as string or name objects
                If objtype = "name" Or objtype = "string" Then
                    info = "/Info[" & i & "]"
                    ResponseWriteLn(Response, "'" & p.pcos_get_string(doc, info) & _
                            "'")
                Else
                    info = "type:/Info[" & i & "]"
                    ResponseWriteLn(Response, "(" & p.pcos_get_string(doc, info) & _
                            " object)")
                End If
                ResponseWriteLn(Response, "<br>")
            Next i
            ResponseWriteLn(Response, "</div>")

            ResponseWriteLn(Response, "<div class=""section"">")
            ResponseWriteLn(Response, "<span class=""section-title"">XMP meta data</span>")

            objtype = p.pcos_get_string(doc, "type:/Root/Metadata")
            If objtype = "stream" Then
                Dim contents() As Byte

                contents = p.pcos_get_stream(doc, "", "/Root/Metadata")
                ResponseWriteLn(Response, "<p>" & contents.Length & " bytes")
            Else
                ResponseWriteLn(Response, "<p>not present")
            End If
            ResponseWriteLn(Response, "</div>")

            p.close_pdi_document(doc)

        Catch ex As PDFlibException
            ResponseWriteLn(Response, "<p>PDFlib exception occurred:")
            ResponseWriteLn(Response, String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            ResponseWriteLn(Response, "<p>Error: " & ex.ToString())
        Finally
            ResponseWriteLn(Response, "</body>")
            ResponseWriteLn(Response, "</html>")
            Response.End()

            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
