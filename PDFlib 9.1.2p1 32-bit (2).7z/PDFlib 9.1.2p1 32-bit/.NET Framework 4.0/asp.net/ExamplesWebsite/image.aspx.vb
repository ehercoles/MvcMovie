    ' $Id$
    '
    ' PDFlib client: image example for ASP.NET
    '
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class image
    Inherits System.Web.UI.Page

    Dim p As PDFlib_dotnet.PDFlib = Nothing

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' This is where font/image/PDF input files live. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Dim image As Integer
        Dim imagefile As String = "nesrin.jpg"
        Dim buf() As Byte

        Try
            p = New PDFlib()

            p.begin_document("", "")

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            p.set_info("Creator", "image.vb.aspx")
            p.set_info("Author", "Rainer Schaaf")
            p.set_info("Title", "image sample (ASP.NET/VB)")

            image = p.load_image("auto", imagefile, "")

            If image = -1 Then
                Response.Write("Error: " & p.get_errmsg())
                Return
            End If

            ' dummy page size, will be adjusted by p.fit_image()
            p.begin_page_ext(10, 10, "")
            p.fit_image(image, 0.0, 0.0, "adjustpage")
            p.close_image(image)

            p.end_page_ext("")

            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=image.vb.aspx.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)
            Response.End()

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
