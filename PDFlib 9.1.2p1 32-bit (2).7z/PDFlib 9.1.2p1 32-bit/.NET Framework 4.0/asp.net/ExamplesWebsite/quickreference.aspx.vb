    ' $Id$
    '
    ' PDFlib+PDI client: mini imposition demo
    '

Imports PDFlib_dotnet
Imports StarterUtils

Partial Class quickreference
    Inherits System.Web.UI.Page

    Dim p As PDFlib_dotnet.PDFlib = Nothing

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' This is where font/image/PDF input files live. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Const inFile As String = "reference.pdf"

        Dim buf() As Byte
        Dim manual, page As Integer
        Dim width, height As Integer
        Dim font, row, col, maxrow, maxcol As Integer
        Dim endpage, pageno As Integer
        Dim optlist As New StringBuilder()

        maxrow = 2
        maxcol = 2

        width = 500
        height = 770


        Try
            p = New PDFlib()

            p.begin_document("", "")

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            p.set_info("Creator", "quickreference.vb.aspx")
            p.set_info("Author", "Thomas Merz")
            p.set_info("Title", "mini imposition demo (ASP.NET/VB)")


            manual = p.open_pdi_document(inFile, "")
            If (manual = -1) Then
                Response.Write("Error: " & p.get_errmsg())
                Return
            End If

            row = 0
            col = 0

            endpage = p.pcos_get_number(manual, "length:pages")

            For pageno = 1 To endpage Step 1
                If (row = 0 And col = 0) Then
                    p.begin_page_ext(width, height, "topdown")
                    font = p.load_font("Helvetica-Bold", "unicode", "")
                    If (font = -1) Then
                        Response.Write("Error: " & p.get_errmsg())
                        Return
                    End If
                    p.setfont(font, 18)
                    p.set_text_pos(24, 24)
                    p.show("PDFlib Quick Reference")
                End If

                page = p.open_pdi_page(manual, pageno, "")
                If (page = -1) Then
                    Response.Write("Error: " & p.get_errmsg())
                    Return
                End If

                optlist.Length = 0
                optlist.AppendFormat("scale {0}", 1 / maxrow)
                p.fit_pdi_page(page, width / maxcol * col, (row + 1) * height / maxrow, optlist.ToString())
                p.close_pdi_page(page)

                col = col + 1
                If (col = maxcol) Then
                    col = 0
                    row = row + 1
                End If

                If (row = maxrow) Then
                    row = 0
                    p.end_page_ext("")
                End If
            Next

            ' finish the last partial page
            If (row <> 0 Or col <> 0) Then
                p.end_page_ext("")
            End If

            p.end_document("")
            p.close_pdi_document(manual)

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=quickreference.vb.aspx.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)
            Response.End()

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
