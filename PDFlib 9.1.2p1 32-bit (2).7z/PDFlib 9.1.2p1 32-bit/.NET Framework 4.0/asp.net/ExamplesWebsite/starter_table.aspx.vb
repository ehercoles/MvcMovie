' $Id$
'
' Table starter:
' Create table which may span multiple pages
'
' required software: PDFlib/PDFlib+PDI/PPS 9
' required data: image file (dummy text created within the program)
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_table
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Const imagefile As String = "nesrin.jpg"

        Dim p As PDFlib_dotnet.PDFlib = Nothing

        Dim row, col, font, image As Integer
        Dim tf As Integer = -1, tbl As Integer = -1
        Const rowmax As Integer = 50, colmax As Integer = 5

        Const llx As Double = 50, lly As Double = 50
        Const urx As Double = 550, ury As Double = 800
        Const headertext As String = "Table header (centered across all columns)"
        Dim result As String
        Dim optlist As String

        ' Dummy text for filling a cell with multi-line Textflow
        Const tf_text As String = _
        "Lorem ipsum dolor sit amet, consectetur adi&shy;pi&shy;sicing elit, sed do eius&shy;mod tempor incidi&shy;dunt ut labore et dolore magna ali&shy;qua. Ut enim ad minim ve&shy;niam, quis nostrud exer&shy;citation ull&shy;amco la&shy;bo&shy;ris nisi ut ali&shy;quip ex ea commodo con&shy;sequat. Duis aute irure dolor in repre&shy;henderit in voluptate velit esse cillum dolore eu fugiat nulla pari&shy;atur. Excep&shy;teur sint occae&shy;cat cupi&shy;datat non proident, sunt in culpa qui officia dese&shy;runt mollit anim id est laborum. "

        Dim buf() As Byte

        ' create a new PDFlib object
        p = New PDFlib()

        Try

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            ' Generate a PDF in memory.
            If p.begin_document("", "") = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_table")

            ' -------------------- Add table cells --------------------

            ' ---------- Row 1: table header (spans all columns)
            row = 1
            col = 1
            font = p.load_font("Times-Bold", "unicode", "")

            If font = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            optlist = "fittextline={position=center font=" & font & _
             " fontsize=14} colspan=" & colmax

            tbl = p.add_table_cell(tbl, col, row, headertext, optlist)

            If tbl = -1 Then
                Throw New System.Exception("Error adding cell: " & _
                    p.get_errmsg())
            End If

            ' ---------- Row 2: various kinds of content
            ' ----- Simple text cell
            row = row + 1
            col = 1

            optlist = _
             "fittextline={font=" & font & " fontsize=10 orientate=west}"

            tbl = p.add_table_cell(tbl, col, row, "vertical line", optlist)

            If tbl = -1 Then
                Throw New System.Exception("Error adding cell: " & _
                    p.get_errmsg())
            End If

            ' ----- Colorized background
            col = col + 1

            optlist = _
                "fittextline={font=" & font & " fontsize=10} " & _
                "matchbox={fillcolor={rgb 0.9 0.5 0}}"

            tbl = p.add_table_cell(tbl, col, row, "some color", optlist)

            If tbl = -1 Then
                Throw New System.Exception("Error adding cell: " & _
                    p.get_errmsg())
            End If


            ' ----- Multi-line text with Textflow
            col = col + 1
            font = p.load_font("Times-Roman", "unicode", "")

            If font = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            optlist = _
             "charref fontname=Times-Roman encoding=unicode fontsize=8 "

            tf = p.add_textflow(tf, tf_text, optlist)
            If tf = -1 Then
                Throw New System.Exception("Error: " + p.get_errmsg())
            End If

            optlist = "margin=2 textflow=" & tf

            tbl = p.add_table_cell(tbl, col, row, "", optlist)

            If tbl = -1 Then
                Throw New System.Exception("Error adding cell: " & _
                    p.get_errmsg())
            End If

            ' ----- Rotated image
            col = col + 1

            image = p.load_image("auto", imagefile, "")
            If image = -1 Then
                Throw New System.Exception("Couldn't load image: " & _
                    p.get_errmsg())
            End If

            optlist = "image=" & image & " fitimage={orientate=west}"

            tbl = p.add_table_cell(tbl, col, row, "", optlist)

            If tbl = -1 Then
                Throw New System.Exception("Error adding cell: " & _
                    p.get_errmsg())
            End If

            ' ----- Diagonal stamp
            col = col + 1

            optlist = "fittextline={font=" & font & " fontsize=10 stamp=ll2ur}"

            tbl = p.add_table_cell(tbl, col, row, "entry void", optlist)

            If tbl = -1 Then
                Throw New System.Exception("Error adding cell: " & _
                    p.get_errmsg())
            End If

            ' ---------- Fill row 3 and above with their numbers
            row = row + 1
            While row <= rowmax
                For col = 1 To colmax
                    Dim num As String = "Col " & col & "/Row " & row

                    optlist = _
                    "colwidth=20% fittextline={font=" & font & " fontsize=10}"
                    tbl = p.add_table_cell(tbl, col, row, num, optlist)

                    If tbl = -1 Then
                        Throw New System.Exception("Error adding cell: " & _
                            p.get_errmsg())
                    End If
                Next col
                row = row + 1
            End While

            ' ---------- Place the table on one or more pages ----------

            '
            ' Loop until all of the table is placed; create new pages
            ' as long as more table instances need to be placed.

            Do
                p.begin_page_ext(0, 0, "width=a4.width height=a4.height")

                ' Shade every other row; draw lines for all table cells.
                ' Add "showcells showborder" to visualize cell borders 
                optlist = _
                "header=1  rowheightdefault=auto " & _
                "fill={{area=rowodd fillcolor={gray 0.9}}} " & _
                "stroke={{line=other}} "

                ' Place the table instance
                result = p.fit_table(tbl, llx, lly, urx, ury, optlist)

                If result = "_error" Then
                    Throw New System.Exception("Couldn't place table : " & _
                        p.get_errmsg())
                End If

                p.end_page_ext("")

            Loop While result = "_boxfull"

            ' Check the result; "_stop" means all is ok.
            If result <> "_stop" Then
                If result = "_error" Then
                    Throw New System.Exception("Error when placing table: " & _
                      p.get_errmsg())
                Else
                    ' Any other return value is a user exit caused by
                    ' the "return" option; this requires dedicated code to
                    ' deal with.

                    Throw New System.Exception("User return found in Table")
                End If
            End If

            ' This will also delete Textflow handles used in the table
            p.delete_table(tbl, "")

            p.end_document("")
            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=starter_table.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
