' $Id$
' PDF merge starter:
' Merge pages from multiple PDF documents; interactive elements (e.g. 
' bookmarks) will be dropped.
'
' required software: PDFlib+PDI/PPS 9
' required data: PDF documents
'
Imports PDFlib_dotnet
Imports StarterUtils

Partial Class starter_pdfmerge
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' This is where the data files are. Adjust as necessary.
        Dim searchpath As String = Server.MapPath("data")

        Dim p As PDFlib_dotnet.PDFlib = Nothing

        Dim pdffiles() As String = _
        { _
         "PDFlib-real-world.pdf", _
         "PDFlib-datasheet.pdf", _
         "TET-datasheet.pdf", _
         "PLOP-datasheet.pdf", _
         "pCOS-datasheet.pdf" _
        }
        Dim pdffile As String
        Dim buf() As Byte

        Try
            p = New PDFlib()

            ' This means we must check return values of load_font() etc.
	    p.set_option("errorpolicy=return")

	    ' Set the search path for fonts and PDF files 
	    p.set_option("SearchPath={{" + searchpath + "}}")

            ' Generate a PDF in memory.
            If p.begin_document("", "") = -1 Then
                Throw New System.Exception("Error: " & p.get_errmsg())
            End If

            p.set_info("Creator", "PDFlib starter sample")
            p.set_info("Title", "starter_pdfmerge")

            For Each pdffile In pdffiles
                Dim indoc, endpage, pageno, page As Integer

                ' Open the input PDF
                indoc = p.open_pdi_document(pdffile, "")
                If indoc = -1 Then
                    Throw New System.Exception("Error: " & p.get_errmsg())
                Else
                    endpage = CInt(p.pcos_get_number(indoc, "length:pages"))

                    ' Loop over all pages of the input document
                    For pageno = 1 To endpage
                        page = p.open_pdi_page(indoc, pageno, "")

                        If page = -1 Then
                            Throw New System.Exception("Error: " & p.get_errmsg())
                        Else
                            ' Dummy page size; will be adjusted later
                            p.begin_page_ext(10, 10, "")

                            ' Create a bookmark with the file name
                            If pageno = 1 Then
                                p.create_bookmark(pdffile, "")
                            End If

                            ' Place the imported page on the output page, and
                            ' adjust the page size
                            p.fit_pdi_page(page, 0, 0, "adjustpage")
                            p.close_pdi_page(page)

                            p.end_page_ext("")
                        End If
                    Next pageno
		    p.close_pdi_document(indoc)
                End If
            Next pdffile

            p.end_document("")

            buf = p.get_buffer()

            Response.Buffer = True
            Response.ContentType = "application/pdf"
            Response.AppendHeader("Content-Disposition", "inline; filename=starter_pdfmerge.pdf")
            Response.AppendHeader("Content-Length", buf.Length.ToString)
            Response.BinaryWrite(buf)

        Catch ex As PDFlibException
            WriteErrorPage(Response, _
                "PDFlib exception occurred:<br>" & _
                String.Format("[{0}] {1}: {2}", ex.get_errnum(), ex.get_apiname(), ex.get_errmsg))
        Catch ex As System.Exception
            WriteErrorPage(Response, "Error: " & ex.ToString())
        Finally
            Response.End()
            If Not p Is Nothing Then
                p.Dispose()
                p = Nothing
            End If
        End Try

    End Sub

End Class
